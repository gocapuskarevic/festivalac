<?php
session_start();
if(isset($_SESSION['sign']))
	$prikaz='<li><a href="novinar/administration/index_a.php">Admin</a></li>';
else $prikaz="";
?>
<!DOCTYPE html>
<html>
<head>
	<title>	Festivalac</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description"  content="Sve muzičke vesti koje vam trebaju na jednom mestu.">
	<meta name="keywords"  content="Festivalac, galerija, muzika, rokenrok, srbija, svirke, koncerti, dešavanja, događaji, albumi, recenzije, reportaže, rock , karte, kupi karte, slike, fotografije, novine, autorski članci, vesti, intervjui, top 10, kolumne" >

	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<style>
		@import url('https://fonts.googleapis.com/css?family=Hind+Siliguri:400,500,600,700|Lato:400,400i,700,700i&subset=latin-ext');
	</style>
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,600i,700,700i&display=swap&subset=latin-ext" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="style.css">
		<script>
			function salji(){
				var vr=document.getElementsByName('field')[0].value;
				window.location.href="categories/search.php?trazise="+vr
			}

			
		</script>
</head>
<body>
	<?php if(isset($_GET['message'])) echo "<script>alert('Hvala što ste se registrovali.Čekamo odobrenje administratora!');</script>";
	require('klase/select_all.php');
	require('klase/load_more.php');
	require('klase/objavi_se.php');

	if(isset($_GET['ann'])) echo "<script>alert('Hvala što ste se prijavili za newsletter!');</script>";
	?>

	<header>
		<div class="container-fluid">
			
			<div class="row">
				<div class="col-sm-12">
					

					<a href="index.php" class="no-pad"><img src="logo_mali.png"></a>
					<nav class="navbar navbar-inverse" style="margin-left: 40px;">
					

						<button class="navbar-toggle pull-left" data-toggle="collapse" data-target=".navHeaderCollapse">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>


						<div class="collapse navbar-collapse navHeaderCollapse">

							
						    <ul class="nav navbar-nav navbar-left">
						   
						      <li><a href="#">VESTI</a></li>
						      <li><a href="categories/category.php?category=2">IZVEŠTAJI</a></li>
						      <li id="taj"><a href="categories/category.php?category=4">ČLANCI</a>
						      		<ul class="nav navbar-nav padajuci">
						      			<li><a href="categories/category.php?category=5">U fokusu</a>
						      			<li><a href="categories/category.php?category=6">Top liste</a>
						      			<li><a href="categories/category.php?category=7">Must-See</a>
						      		</ul>
						      </li>
						      <li><a href="categories/category.php?category=3">INTERVJUI</a></li>
						      <li><a href="categories/gallery.php">GALERIJA</a></li>
						      <?php echo $prikaz; ?>
						      <li style="margin-top: 3px;"><input type="text" name="field" class="form-control" style="display:inline;" placeholder="Pretraži vesti..." maxlength="30"></li>
						      <li><a href="#" onclick="salji();"><i class="fa fa-search"></i></a></li>
						    </ul>
				</div><!--ovaj div drzi sve za hamburger meni posle-->
	

						   <div class="top-right">
						    	<a href=""><i class="fab fa-instagram" title="Instagram"></i></a>
						    	<a href=""><i class="fa fa-twitter-square" title="Twiter"></i></a>
						    	<a href="https://www.facebook.com/nemanja.neskovic.73"><i class="fa fa-facebook-square" title="Facebook"></i></a>
						    	<a href="eng/index.php"><img src="flag.png" style="width:35px;height: 30px;"></a>
						    	
						    </div>

						    
						</nav>

						
			
			</div>
			
		</div>
		<div id="latest-new">
			<div class="col-sm-12 col-md-10 col-md-offset-1">
			<?php $glavna=new Display($main_news['naslov'],$main_news['tekst'],$main_news['slika'],$main_news['vreme'],$main_news['sifra']);
				$glavna->latest_news();
				?>
				</div>
						</div><!--zavrsetak naslovne vesti-->
</div>
		
	</header><!-- zavrsava se header tu su linkovi ka mrežama i navigacija-->
	
		<div class="container-fluid">
			<div class="row">
				<main>
				<div class="col-md-10 col-md-offset-1 col-sm-12 centar">
					<div class="row">
						<div class="col-md-8 col-sm-12">
							<section>
								<h2>Najnovije vesti</h2>
								
									<div id="najcitanije"></div>
								
								
								
								<div id="centar"><button class="btn bt" onclick="ucitaj_jos();">Učitaj još...</button></div>
							</section><!--ovo je deo sa novim vestima-->
						</div><!--ovo je deo sa novim vestima-->
						<div class="col-md-4 col-sm-12">
							<section>
								<h2>Izdvajamo</h2>
								
								<?php 
								while($vest=$sa_strane->fetch_assoc()){
									$vesti=new Display($vest['naslov'],$vest['tekst'],$vest['slika'],$vest['vreme'],$vest['sifra']);
									$vesti->aside_show();
								}   ?>
								
							</section>
							<section>
								<div id="newsletter"><!--OVO JE DIV ZA NEWSLETTER#############################-->
									<p>Želite da redovno dobijate nove vesti? Prijavite se...</p>
										<div class="form-group">
											<form method="post" action="klase/newsletter.php">
												<label for="first_name">Vaše ime<br>
													<input type="text" name="first_name" id="first_name" maxlength="40" class="form-control" required></label><br>
													<label for="email">Vaš email<br>
													<input type="email" name="email" id="email" maxlength="50" class="form-control" required></label><br>
													<button type="submit" class="btn bt" name="podaci">Sačuvaj podatke</button>
													
											</form>
										
									</div><!--OVO JE DIV ZA NEWSLETTER#############################-->
							</section>
						
						</div>
					</div><!--ovo je deo sa najcitanijim vestima-->
					</div>
				
				</main><!-- zavrsava se main tu su glavne vesti po kategorijama i sa strane najcitanije--><!-- zavrsava se main i aside tu su glavne vesti po kategorijama i sa strane najcitanije-->
			</div>
		</div>
		</div>

		<div class="container-fluid">
			<div class="col-md-10 col-md-offset-1">
				<section>
				<h2 class="no_bottom_line">Izveštaji</h2>
				<?php
				while($izv=$izvestaji->fetch_assoc()){
					$izvestaj_obj=new Display($izv['naslov'],$izv['tekst'],$izv['slika'],$izv['vreme'],$izv['sifra']);
					$izvestaj_obj->izvestaj();
				}
					
					?>
			

			
		</section><!-- ovde se zavrsava deo sa izvestajima-->
			<section>
				<h2 class="no_bottom_line">Galerija</h2>
			
				<?php
					require_once('klase/gallery_main.php');
					$prikaz="";
					while($galerija=$gallery->fetch_assoc()){
						$img=$kon->query("SELECT naziv_slike,odakle FROM slike_galerija WHERE folder=".$galerija['sifra_g']." LIMIT 1");
						$img=$img->fetch_assoc();
						if($img['odakle']!=1) $prikaz='<a href="categories/selected_gallery.php?num='.$galerija['sifra_g'].'">'.$img['naziv_slike'].'</a>';
						else $prikaz='<a href="categories/selected_gallery.php?num='.$galerija['sifra_g'].'"><img src="gallery/'.$galerija['naziv_foldera'].'/'.$img['naziv_slike'].'" alt="Galerija slika">';

						$pr=str_replace('-', '/',$galerija['naziv_foldera']);
						$pr2=str_replace('_','.',$pr);

						echo '<div class="col-md-4 col-sm-12 hover" style="text-align:center;"><a href="categories/selected_gallery.php?num='.$galerija['sifra_g'].'">'.$prikaz.'
							<figcaption><strong>'.$pr2.'</strong></figcaption></a></div>';
					}
				 ?>
			

			
		</section><!-- ovde se zavrsava galerija-->
		</div>
	</div>
		
	
	<aside>
		<div class="container-fluid"><section>
			<div class="row">
				<div class="col-sm-12 col-md-8 col-md-offset-2">
					
						<div class="col-sm-12 col-md-4">
							<h2><a href="categories/category.php?category=2">Članci</a></h2>
							<?php 
								while($iz=$clanak->fetch_assoc()){
									$sh_izvestaj=new Display($iz['naslov'],$iz['tekst'],$iz['slika'],$iz['vreme'],$iz['sifra']);
									$sh_izvestaj->footer_news();
								}   ?> 
							
						</div>
						
						<div class="col-sm-12 col-md-4">
							<h2><a href="categories/category.php?category=3">Intervjui</a></h2>
							<?php 
								while($int=$intervju->fetch_assoc()){
									$sh_intervju=new Display($int['naslov'],$int['tekst'],$int['slika'],$int['vreme'],$int['sifra']);
									$sh_intervju->footer_news();
								}   ?> 
							
						</div>
						<div class="col-sm-12 col-md-4">
							<h2><a href="categories/category.php?category=8">Koncerti</a></h2>
							
							
						</div>
					
				</div>
			</div>
		</section>
		</div><!-- zavrsava se aside sa malim vestima po kategorijama-->


	</aside>
	<div class="smoot"><a href="#"><i class="fas fa-angle-up"></i></a></div>
	<script type="text/javascript">
	window.onscroll = function() {myFunction()};
function myFunction() {
  if (document.documentElement.clientHeight > 550) {
    document.getElementsByClassName("smoot")[0].style.display = "block";
  }
  if(document.documentElement.clientHeight < 969)document.getElementsByClassName("smoot")[0].style.display = "none";
}
		
	</script>
<section>
		<div class="container-fluid">
			<div class="row">
				<div class="col-sm-12 col-md-8 col-md-offset-2 text-center">
					<div class="col-sm-12 col-md-8 col-md-offset-2 text-center"><img src="facebook_cover_photo_1.png">
							<a href="#" class="footer-a">O nama</a>
							<a href="categories/impressum.php" class="footer-a">Impressum</a>
							<a href="categories/contact.php" class="footer-a">Kontakt</a>
								
						</div>
				
				</div>
				
			</div>
		</div>
	</section>



	<footer>
		<p title="s_goca@yahoo.com">GP&copy; 2019</p>
	</footer>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	  <script type="text/javascript" src="script.js"></script>


</body>
</html>