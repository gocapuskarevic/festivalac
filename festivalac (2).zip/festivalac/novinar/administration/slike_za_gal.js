var ajax_galerija = new XMLHttpRequest();
var sifra;
function napravigaleriju(param){
    
        if(document.getElementById('naslov').value==""){
            alert("Galerija mora imati naslov");//ako nije dodeljeno ime galeriji
        }else{//inace pravimo folder i dajemo ime
            param.disabled=true;
            document.getElementById('naslov').disabled=true;
            ajax_galerija.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    sifra=this.responseText;
                 }
            }
            ajax_galerija.open("GET", "ajax/napravi_galeriju.php?naslov="+document.getElementById('naslov').value+"&vest="+document.getElementById('vest').value, true);
        
            ajax_galerija.send();
            
        }  
}
  



function dodaj_sliku(){

    if(document.getElementById('upload').value!=""||document.getElementById('snimi').value!=""){
        if(document.getElementById('upload').value!=""){
        var form = document.querySelector("#formica");
        var fm = new FormData(form);
        ajax_galerija.open("POST", "ajax/insert_sliku.php?folder="+sifra, true);
        ajax_galerija.send(fm);
        ajax_galerija.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById('ob').innerHTML=this.responseText;
            }
        }
    }else if(document.getElementById('snimi').value!=""){
        ajax_galerija.open("POST", "ajax/insert_sliku.php?folder="+sifra, true);
        ajax_galerija.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        ajax_galerija.send("folder="+sifra+"&slika="+document.getElementById('snimi').value);
        document.getElementById('snimi').value="";
        ajax_galerija.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                //alert(this.responseText);
            }
        }   
    }
}else alert('Izaberite sliku prvo');
}