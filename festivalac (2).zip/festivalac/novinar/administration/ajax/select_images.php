<?php
require_once('../../../klase/PDO.php');
$folder=$_GET['galerija'];

$slike=$kon->query('SELECT folder,naziv_slike,odakle,naziv_foldera FROM slike_galerija INNER JOIN galerija ON galerija.sifra_g=slike_galerija.folder WHERE folder='.$folder.'');



	$array=array();
	while($row=$slike->fetch_assoc())
		$array[]=$row;
	

	echo json_encode($array);



?>