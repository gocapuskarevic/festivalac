<?php
require('../../../klase/PDO.php');



$post="SELECT vest.sifra,vest.naslov,vest.vreme,vest.klik,vest.status,novinar.ime,kategorija.naziv AS kat FROM vest INNER JOIN kategorija ON kategorija.sifra=vest.kategorija INNER JOIN novinar ON novinar.sifra=vest.autor ORDER BY vest.sifra DESC"; 

$posti=$kon->query($post);

	
		$niz=array();
		while($postovi=$posti->fetch_assoc()){
			$niz[]=$postovi;
		}

echo json_encode($niz);






?>