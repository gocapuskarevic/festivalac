<?php
require('../../../klase/PDO.php');

if(isset($_GET['parametar']))
	$pa=$_GET['parametar'];
else $pa=1;


$post="SELECT vest_eng.sifra,vest_eng.naslov,vest_eng.klik,vest_eng.status,vest_eng.vreme,kategorija.naziv,novinar.ime FROM vest_eng INNER JOIN novinar ON vest_eng.autor=novinar.sifra INNER JOIN kategorija ON kategorija.sifra=vest_eng.kategorija WHERE vest_eng.status=".$pa." ORDER BY vest_eng.sifra DESC";


$posti=$kon->query($post);

		$niz=array();
		while($postovi=$posti->fetch_assoc()){
			$niz[]=$postovi;
		}

echo json_encode($niz);


?>