<?php
require('../../../klase/PDO.php');
$folder=$_POST['folder'];
$ime=$kon->query("SELECT naziv_foldera FROM galerija WHERE sifra_g=$folder");
$ime=$ime->fetch_assoc()['naziv_foldera'];

$res=$kon->prepare("INSERT INTO slike_galerija(folder,naziv_slike,odakle) VALUES(?,?,?)");
if(isset($_POST['slika'])){
	$slika="<img src='".$_POST['slika']."' alt='Slika'>";
	$putanja=0;
		if($res->bind_param('isi',$folder,$slika,$putanja)){
			if($res->execute()){
				echo "Slika je sačuvana";
			}else echo $kon->error;
	}else echo $kon->error;

}else if(!isset($_POST['slika'])){
	$folder=$_GET['folder'];
	if(move_uploaded_file($_FILES['image']['tmp_name'], '../../../gallery/'.$ime.'/'.$_FILES['image']['name'])){
		$slika=$_FILES['image']['name'];
		$putanja=1;
			if($res->bind_param('isi',$folder,$slika,$putanja)){
				if($res->execute()){
					echo "Slika je sačuvana";
				}else echo $kon->error;
			}else echo $kon->error;
	}else echo "Slika nije sačuvana";

}else header('Location:../../../index.php');

?>