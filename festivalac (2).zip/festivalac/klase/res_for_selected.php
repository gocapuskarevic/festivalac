<?php
require('PDO.php');
require('selected.php');
if(is_numeric($_GET['number'])){
	$res=$kon->query('SELECT vest.sifra AS sifra,vest.naslov,vest.tekst,vest.vreme,vest.kategorija,vest.slika,novinar.ime FROM vest INNER JOIN novinar ON novinar.sifra=vest.autor WHERE vest.status=1 AND vest.sifra='.$_GET['number'].'');
	$tagovi=$kon->query("SELECT tagovi.imetaga,tagovi.sifra FROM tagovi INNER JOIN tag_vest ON tag_vest.tag=tagovi.sifra WHERE tag_vest.vest=".$_GET['number']."");
	if(!$tagovi) echo $kon->error;
	
	$kon->query("CALL povecaj(".$_GET['number'].")");

}else header('Location:../index.php');
















?>