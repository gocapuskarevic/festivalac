<?php
class Selected{
	private $title;
	private $author;
	private $date;
	private $img_path="../images/";
	private $content;

	private $user;
	private$comment;

	public function __construct($title,$au,$date,$img,$con){
		$this->title=$title;
		$this->author=$au;
		$this->date=$date;
		$this->img_path.=$img;
		$this->content=$con;
	}

	public function show($kateg){
		if($kateg==2||$kateg==4)
			$autor='<div><p>Autor: '.$this->author.'</p></div>';
		else $autor="";
		$datum=substr($this->date,0,10);
		$priv=explode('-', $datum);
		$priv=array_reverse($priv);
		$datum=implode('-', $priv);
		echo '<h1>'.$this->title.'</h1>
				<p><i>Datum: '.$datum.'</i></p>'.$autor.'<img src="'.$this->img_path.'" alt="Slika">
				<p id="frst">'. html_entity_decode($this->content).'</p>';

				//<p><i>Autor: '.$this->author.'</i> </p>
	}

	public function tags($sifra,$ime){
		echo '<div class="tagovi"><a href="search.php?trazise='.$sifra.'">#'.$ime.'</a></div>';
	}

	public function comments($aut,$con,$date){
		$this->user=$aut;
		$this->comment=$con;
		$this->date=$date;
		echo '<section><p><b>'.$this->user.': </b>'.$this->comment.'</p>
			  <p><i>Datum: '.$this->date.'</i></p>
			  </section>';

	}

		public function show_fast($image){//ovo je adminu da vidi tudje vesti kako izgledaju
			$this->img_path="../../images/".$image;
		echo '<h1>'.$this->title.'</h1>
				<p><i>Autor: '.$this->author.'</i> </p>
				<p>Datum: <input type="datetime-local" name="novo_vreme" class="form-control" value="'. $this->date.'" > </p>
				<img src="'.$this->img_path.'" alt="Slika" style="max-width:100%;">
				<p id="frst">'. html_entity_decode($this->content).'</p>';
	}

}


















?>