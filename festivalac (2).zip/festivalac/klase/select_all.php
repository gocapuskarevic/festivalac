<?php
require('PDO.php');
require('display.php');

require_once('PDO.php');
$res=$kon->query("SELECT * FROM glavna ORDER BY datum DESC LIMIT 1");
while($r=$res->fetch_assoc()){
	$date=new DateTime($r['datum'],new DateTimeZone('Europe/Belgrade'));
		if($date->getTimestamp()>time()){
			$si=$r['vest'];
			$main_news=$kon->query('SELECT * from vest WHERE status=1 AND sifra='.$si.'');
			$main_news=$main_news->fetch_assoc();
		}else{
			$main_news=$kon->query('SELECT * from vest WHERE status=1 ORDER BY vreme_objave DESC LIMIT 1');
			$main_news=$main_news->fetch_assoc();//ovaj deo je za glavnu vest,trazi id i pravi dalje instancu
		}
}




//ako nema izdvajamo



//sada selektuje najcitanije za deo sa strane
$sa_strane=$kon->query('SELECT vest.sifra,vest.naslov,vest.tekst,vest.vreme,vest.slika from vest INNER JOIN izdvajamo ON vest.sifra=izdvajamo.vest WHERE vest.status=1 ORDER BY vest.sifra DESC LIMIT 3');

$clanak=$kon->query('SELECT * FROM vest WHERE kategorija=4 AND status=1 ORDER BY vreme DESC LIMIT 3');
$intervju=$kon->query('SELECT * FROM vest WHERE kategorija=3 AND status=1 ORDER BY vreme DESC LIMIT 3');


$izvestaji=$kon->query('SELECT * FROM vest WHERE kategorija=2 AND status=1 ORDER BY vreme DESC LIMIT 3');



















?>