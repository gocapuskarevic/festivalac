<?php
class Ch_cat{
	private $image_path="../images/";
	private $title;
	private $secret;
	private $selected="selected-news.php?number=";

	public function __construct($img,$title,$sec){

		$this->image_path.=$img;
		$this->title=$title;
		$this->secret=$sec;
		$this->selected.=$this->secret;
	}

	public function last_news(){
		echo '<div id="last-new">
			<img src="'.$this->image_path.'" alt="Slika">
			</div>
			<h1 style="font-size:3vw;"><a href="'.$this->selected.'" class="undrl">'.$this->title.'</a></h1>';
	}

	public function all_news(){
		echo '<div class="col-sm-12 col-md-6 float_left cat_height"><article class="btm"><img src="'.$this->image_path.'" class="img_float-left">
					<div><h3 class="no-top-margin"><a href="'.$this->selected.'" class="undrl">'.$this->title.'</a></h3>
					</div></article></div>';
	}
	}
//<p>'.substr($content,0,120).'...</p>
?>