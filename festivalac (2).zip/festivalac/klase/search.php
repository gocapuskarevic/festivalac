<?php
require('PDO.php');
if(!empty($_GET['trazise'])){
	$vrednost=strtolower($_GET['trazise']);
		$srch=$kon->query("SELECT vest.sifra,vest.naslov,vest.tekst,vest.slika FROM vest INNER JOIN tag_vest ON tag_vest.vest=vest.sifra INNER JOIN tagovi ON tagovi.sifra=tag_vest.tag WHERE (tag_vest.tag='$vrednost' OR tagovi.imetaga LIKE '%".$vrednost."%') AND vest.status=1");
	}

else header('Location:../index.php');




?>