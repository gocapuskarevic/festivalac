<?php
session_start();
include_once('../klase/PDO.php');
if(isset($_POST['novi_p'])){
	$vec_postoje=$kon->query("SELECT mail FROM novinar");
	$novinari=array();
	while($postoji=$vec_postoje->fetch_assoc()){
		array_push($novinari, $postoji['naziv_foldera'])
	}

	if(isset($_POST['ime_n'])&&isset($_POST['mail_n'])&&isset($_POST['pass_n'])&&isset($_POST['pass_a'])){
		if(!in_array($_POST['pass_n'], $novinari)){
			$ime=trim(htmlspecialchars($_POST['ime_n']));
			$mail=md5(trim(htmlspecialchars($_POST['mail_n'])));
			$pass1=md5(trim(htmlspecialchars($_POST['pass_n'])));
			$pass2=md5(trim(htmlspecialchars($_POST['pass_a'])));
			if($pass1===$pass2){
				$br=1;
				$prepare=$kon->prepare("INSERT INTO novinar(ime,password,mail,master) VALUES (?,?,?,?)");
				$prepare->bind_param('sssi',$ime,$pass1,$mail,$br);
				$res=$prepare->execute();
					if($res){
					$message="Odobravanje korisniku $ime klikom na <a href='festivalac/pristup/grant.php?kor=$mail'>ovaj link</a>";
					mail("nemanjaneskovic@gmail.com","odobrenje",$message);
					header('Location:../index.php?message=wait');
					exit();
				}else header('Location:../journalist_admin.php?error=no');//nije ubaceno u bazi
			}else header('Location:../journalist_admin.php?error=wrpas');//ne podudaraju se obe sifre
		}else header('Location:../journalist_admin.php?error=exist_email');//vec mail postoji
		
	}else header('Location:../journalist_admin.php?error=je');//neko polje je prazno
}else header('Location:../journalist_admin.php?error=je');




























?>