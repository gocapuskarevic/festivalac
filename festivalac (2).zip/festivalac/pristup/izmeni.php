<?php
session_start();
require_once('../klase/PDO.php');
$provera=$kon->query("SELECT mail FROM novinar");
$niz=array();
while($red=$provera->fetch_array())
	array_push($niz, $red['mail']);
if(in_array($_SESSION['sign'], $niz)){
	$sifra=$_POST['sifra'];
	$update="UPDATE vest SET naslov=?,tekst=?,kategorija=? WHERE sifra=?";//za update
	if(isset($_POST['eng'])||isset($_POST['srb'])){
		if(isset($_POST['eng'])){
			 $lang=1;
			 $update="UPDATE vest_eng SET naslov=?,tekst=?,kategorija=? WHERE sifra=?";//za update
		}else{
			$lang=0;
			$update="UPDATE vest SET naslov=?,tekst=?,kategorija=? WHERE sifra=?";//za update
		} 
		if(!empty($_POST['title'])&&!empty($_POST['content'])){
			$title=trim($_POST['title']);
			$content=trim($_POST['content']);
			$cat=$_POST['category'];
			//ako nije sacuvana slika vraca na index inace idemo dalje
			//sad pravimo ostale promenljive za sve
			
			if($result=$kon->prepare($update)){
				if($result->bind_param('ssii',$title,$content,$cat,$sifra)){
				if($result->execute()){
					
					
				if($_FILES['image']['size']>0){
					$slika=$_FILES['image']['name'];
						if(move_uploaded_file($_FILES['image']['tmp_name'],"../images/".$_FILES['image']['name'])){
							if($lang)
								$kon->query("UPDATE vest_eng SET slika='".$slika."' WHERE sifra=$sifra");
							else $kon->query("UPDATE vest SET slika='".$slika."' WHERE sifra=$sifra");
						}else echo "nije snimljena slika";
					}
					//ovde se dodaju tagovi u bazu
					$tagovi=$_POST['tagovi'];
					if($tagovi){
						$tag = explode(",", $tagovi);
						for($i=0;$i<count($tag)-1;$i++){
							if(preg_match('~[0-9]+~', $tag[$i])){
								if($lang){
									$dodati=$kon->query("INSERT INTO tag_vest_eng(vest_eng,tag) VALUES($sifra,$tag[$i])");
								if(!$dodati)
									echo $kon->error;
							}else{
								$dodati=$kon->query("INSERT INTO tag_vest(vest,tag) VALUES($sifra,$tag[$i])");
								if(!$dodati)
									echo $kon->error;
							}
								
							}else if(!preg_match('~[0-9]+~', $tag[$i])){
								$ubacujemo_novi=$kon->query("INSERT INTO tagovi(imetaga) VALUES('$tag[$i]')");
								if(!$ubacujemo_novi) echo $kon->error;
								$sifra_tag=$kon->insert_id;
								if($lang){
									$dodajemo_opet=$kon->query("INSERT INTO tag_vest_eng(vest_eng,tag) VALUES($sifra,$sifra_tag)");
									if(!$dodajemo_opet)
										echo $kon->error;//header('Location:../novinar/administration/index_a.php?ann=nijeprosaoinsertnovi_tag');
								}else{
									$dodajemo_opet=$kon->query("INSERT INTO tag_vest(vest,tag) VALUES($sifra,$sifra_tag)");
									if(!$dodajemo_opet)
										echo $kon->error;//header('Location:../novinar/administration/index_a.php?ann=nijeprosaoinsertnovi_tag');
								}
								
							}
						}//zavrsava se for petlja ovde
						
					}//else echo $kon->error;//header('Location:../novinar/administration/index_a.php?ann=nematagova');
					
					header('Location:../novinar/administration/index_a.php?ann=true');

					
				}else echo $kon->error;//header('Location:../novinar/administration/index_a.php?ann=nijeprosaoexecute');

			}else echo $kon->error;//header('Location:../novinar/administration/index_a.php?ann=nijeprosaobind');
			}else echo $kon->error;
			


		}else header('Location:../novinar/administration/index_a.php?ann=empty');

	}else header('Location:../index.php');
	




}else header('Location:../index.php');

?>