<?php
$ime_folder="";
$slike=array();













?>