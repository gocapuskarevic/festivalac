<?php
require('../klase/PDO.php');
$ime_foldera=$_GET['folder'];
$sifra_foldera=$kon->query("SELECT sifra_g FROM galerija WHERE naziv_foldera='$ime_foldera'");
$sifra_foldera=$sifra_foldera->fetch_assoc()['sifra_g'];
if(!$_FILES['file']['error']){
	$ime_slike=$_FILES['file']['name'];
	$dodaj=move_uploaded_file($_FILES['file']['tmp_name'], '../gallery/'.$ime_foldera.'/'.$ime_slike);
	if($dodaj){
		$res=$kon->prepare("INSERT INTO slike_galerija(folder,naziv_slike) VALUES(?,?)");
		$res->bind_param('is',$sifra_foldera,$ime_slike);
		if($res->execute())
			echo "Slika je sačuvana.";
		else echo "Slika je uploadovana,ali nije ubačena u tabelu.";
	}else echo "Slika nije uploadovana!";

}else echo "Prvo izaberite sliku";


?>