<?php
require("../klase/pdo.php");
$svi=$kon->query("SELECT naziv_foldera FROM galerija");
$niz_svi=$svi->fetch_assoc();
if(!in_array($_GET['naslov_g'], $niz_svi)){
	mkdir('../gallery/'.$_GET['naslov_g']);
	$gall=$kon->prepare("INSERT INTO galerija (naziv_foldera,vest) VALUES(?,?)");
	$gal=$_GET['naslov_g'];
	$vest=0;
	$gall->bind_param('si',$gal,$vest);
	if($gall->execute()){
		echo "Galerija je napravljena,sad dodajte slike";

	}else echo "sifra greske je ".$kon->errno;

}else echo "Izaberite drugo ime,ovo već postoji u bazi!";

//echo "juhu";

?>