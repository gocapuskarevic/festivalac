<?php
include_once('../klase/PDO.php');
if(isset($_POST['grant'])){
	if($_POST['grant']=='Odobri'){
		$grant=$kon->prepare("UPDATE komentari SET odobri=? WHERE sifra=?");
		$odobrenje=1;
		$sifra=$_POST['hdn'];
		$grant->bind_param('ii',$odobrenje,$sifra);
		if($grant->execute()){
			header('Location:../novinar/administration/comments_p.php?ann=comm_true');
		}else header('Location:../novinar/administration/comments_p.php?ann=comm_false');
	}else if($_POST['grant']=='Obrisi'){
		//$grant=$kon->prepare("DELETE * FROM komentari WHERE sifra=?");
		$sifra=$_POST['hdn'];
		$grant=$kon->prepare("DELETE FROM komentari WHERE sifra=?");
		$grant->bind_param('i',$sifra);
		if($grant->execute())
		header('Location:../novinar/administration/comments_p.php?ann=comm_del_true');
		}else header('Location:../novinar/administration/comments_p.php?ann=comm_del_false');



}else header('Location:../index.php');



?>
