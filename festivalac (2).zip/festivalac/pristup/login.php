<?php
session_start();
include_once('../klase/PDO.php');
$warrning="<script>
		window.location.assign('../journalist_admin.php?error=je');
	</script>";

if(isset($_POST['podaci'])){
	if(isset($_POST['ime'])&&isset($_POST['loz'])){
		$mail=md5(trim(htmlspecialchars($_POST['ime'])));
		$pass=md5(trim(htmlspecialchars($_POST['loz'])));
		$res=$kon->query('SELECT * FROM novinar WHERE mail="'.$mail.'"');
		if($res){
			$no=$res->fetch_assoc();
			if($no['mail']==$mail&&$no['password']==$pass){
			$_SESSION['sign']=$no['mail'];
			header('Location:../novinar/administration/index_a.php');
			exit();
			}else echo $warrning;
		}else echo $warrning;
	}else echo $warrning;
}else echo $warrning;




?>