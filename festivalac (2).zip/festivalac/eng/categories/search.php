<?php include('../include/header.html');?>
<script>
			function salji(){
				var vr=document.getElementsByName('field')[0].value;
				window.location.href="search.php?trazise="+vr
			}
		</script>
<body>

		<header>
		<div class="container-fluid">
			
			<div class="row">
				<div class="col-sm-12">
					

					<a href="../index.php" class="no-pad"><img src="../../logo_mali.png"></a>
					<nav class="navbar navbar-inverse" style="margin-left: 40px;">
					

						<button class="navbar-toggle pull-left" data-toggle="collapse" data-target=".navHeaderCollapse">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>


						<div class="collapse navbar-collapse navHeaderCollapse">

							
						    <ul class="nav navbar-nav navbar-left">
						   
						       <li><a href="../index.php">NEWS</a></li>
						      <li><a href="category.php?category=2">REPORTS</a></li>
						      <li id="taj"><a href="category.php?category=4">ARTICLES</a>
						      		<ul class="nav navbar-nav padajuci">
						      			<li><a href="category.php?category=5">In focus</a>
						      			<li><a href="category.php?category=6">Top liste</a>
						      			<li><a href="category.php?category=7">Must-See</a>
						      		</ul>
						      </li>
						      <li><a href="category.php?category=3">INTERVIEW</a></li>
						      <li><a href="gallery.php">GALLERY</a></li>
						      <li style="margin-top: 3px;"><input type="text" name="field" class="form-control" style="display:inline;" placeholder="Search..." maxlength="30"></li>
						      <li><a href="#" onclick="salji();"><i class="fa fa-search"></i></a></li>
						    </ul>
				</div><!--ovaj div drzi sve za hamburger meni posle-->
	

						   <div class="top-right">
						    	<a href=""><i class="fab fa-instagram" title="Instagram"></i></a>
						    	<a href=""><i class="fa fa-twitter-square" title="Twiter"></i></a>
						    	<a href="https://www.facebook.com/nemanja.neskovic.73"><i class="fa fa-facebook-square" title="Facebook"></i></a>
						    	<a href="../../index.php"><img src="../srbija.png" style="width:35px;height: 30px;"></a>
						    </div>

						    
						</nav>

						
			
			</div>
			
		</div>

</div>
		
	</header><!-- zavrsava se header tu su linkovi ka mrežama i navigacija-->
<div class="container-fluid">
		<div class="row">
			<div class="col-md-8 col-md-offset-2 col-sm-12 proba">
				<section>
					<h1>Searching results</h1>
					<?php
					include("../klase/search.php");
					include("../klase/ch_cat.php");
					if($srch->num_rows>0){
						while($red=$srch->fetch_assoc()){
							$objekat=new Ch_cat($red['slika'],$red['naslov'],$red['sifra']);
							$objekat->all_news($red['tekst']);
						}
					}else echo '<p>No results</p>';
					  ?>
				</section>
			</div>
		</div>
		
	</div>
		<div class="smoot"><a href="#"><i class="fas fa-angle-up"></i></a></div>
	<script type="text/javascript">
	window.onscroll = function() {myFunction()};
function myFunction() {
  if (document.documentElement.clientHeight > 350) {
    document.getElementsByClassName("smoot")[0].style.display = "block";
  }else if(document.documentElement.clientHeight < 350)document.getElementsByClassName("smoot")[0].style.display = "none";
}
		
	</script>
<?php include('../include/footer.html');?>
</body>
</html>