<?php
session_start();
if(isset($_SESSION['sign']))
	$prikaz='<li><a href="../../novinar/administration/index_a.php">Admin</a></li>';
else $prikaz="";
?>
<script>
			function salji(){
				var vr=document.getElementsByName('field')[0].value;
				window.location.href="search.php?trazise="+vr
			}
		</script>
<?php include('../include/header.html');?>
<body>


		<header>
		<div class="container-fluid">
			
			<div class="row">
				<div class="col-sm-12">
					

					<a href="../index.php" class="no-pad"><img src="../../logo_mali.png"></a>
					<nav class="navbar navbar-inverse" style="margin-left: 40px;">
					

						<button class="navbar-toggle pull-left" data-toggle="collapse" data-target=".navHeaderCollapse">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>


						<div class="collapse navbar-collapse navHeaderCollapse">

							
						    <ul class="nav navbar-nav navbar-left">
						   
						       <li><a href="../index.php">NEWS</a></li>
						      <li><a href="category.php?category=2">REPORTS</a></li>
						      <li id="taj"><a href="category.php?category=4">ARTICLES</a>
						      		<ul class="nav navbar-nav padajuci">
						      			<li><a href="category.php?category=5">In focus</a>
						      			<li><a href="category.php?category=6">Top liste</a>
						      			<li><a href="category.php?category=7">Must-See</a>
						      		</ul>
						      </li>
						      <li><a href="category.php?category=3">INTERVIEW</a></li>
						      <li><a href="gallery.php">GALLERY</a></li>
						      <?php echo $prikaz; ?>
						      <li style="margin-top: 3px;"><input type="text" name="field" class="form-control" style="display:inline;" placeholder="Search..." maxlength="30"></li>
						      <li><a href="#" onclick="salji();"><i class="fa fa-search"></i></a></li>
						    </ul>
				</div><!--ovaj div drzi sve za hamburger meni posle-->
	

						   <div class="top-right">
						    	<a href=""><i class="fab fa-instagram" title="Instagram"></i></a>
						    	<a href=""><i class="fa fa-twitter-square" title="Twiter"></i></a>
						    	<a href="https://www.facebook.com/nemanja.neskovic.73"><i class="fa fa-facebook-square" title="Facebook"></i></a>
						    	<a href="../../index.php"><img src="../srbija.png" style="width:35px;height: 30px;"></a>
						    </div>

						    
						</nav>

						
			
			</div>
			
		</div>

</div>
		
	</header><!-- zavrsava se header tu su linkovi ka mrežama i navigacija-->
		<div class="container-fluid">
		<div class="row">
			<div class="col-md-8 col-md-offset-2 col-sm-12 proba">
				<section>
					<?php
				include('../klase/only_cat.php');
				if($cat_result->num_rows>0){
					$first=$cat_result->fetch_assoc()['sifra'];
					$tmp=$kon->query('SELECT vest_eng.slika,vest_eng.naslov,novinar.ime FROM vest_eng INNER JOIN novinar ON vest_eng.autor=novinar.sifra WHERE vest_eng.sifra='.$first.'');
					$glavna=$tmp->fetch_assoc();

					//ovo je bilo na ovoj strani pre
					$vest=new Ch_cat($glavna['slika'],$glavna['naslov'],$first);
					$vest->last_news();

	
				}else echo("Soon...");
					

					?>
	
				</section>

				<main>
					<section>
				<h2>All from category...</h2>
				<?php while($rows=$cat_result->fetch_assoc()){
					if(($rows['sifra']!=$first)||($rows['sifra']!=false)){
						$ostale=new Ch_cat($rows['slika'],$rows['naslov'],$rows['sifra']);
					$ostale->all_news();
					}
					
				} ?>

				<article class="btm">
					
		
				</article>
			</section>

			</main>
			
			</div>

			
		</div>
	</div>
		<div class="smoot"><a href="#"><i class="fas fa-angle-up"></i></a></div>
	<script type="text/javascript">
	window.onscroll = function() {myFunction()};
function myFunction() {
  if (document.documentElement.clientHeight > 350) {
    document.getElementsByClassName("smoot")[0].style.display = "block";
  }else if(document.documentElement.clientHeight < 350)document.getElementsByClassName("smoot")[0].style.display = "none";
}
		
	</script>
<?php include('../include/footer.html');?>
</body>
</html>

