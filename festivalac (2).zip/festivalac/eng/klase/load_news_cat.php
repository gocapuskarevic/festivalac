<?php
require('PDO.php');

if(isset($_GET['parametar']))
	$pa=$_GET['parametar'];
else $pa=1;


$post="SELECT vest.sifra,vest.naslov,vest.klik,vest.status,vest.vreme,kategorija.naziv,novinar.ime FROM vest INNER JOIN novinar ON vest.autor=novinar.sifra INNER JOIN kategorija ON kategorija.sifra=vest.kategorija WHERE vest.status=".$pa." ORDER BY vest.sifra DESC";


$posti=$kon->query($post);

		$niz=array();
		while($postovi=$posti->fetch_assoc()){
			$niz[]=$postovi;
		}

echo json_encode($niz);


?>