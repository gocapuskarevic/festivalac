<?php
if(isset($_POST['por'])){
	$ime=trim(htmlspecialchars($_POST['ime']));
	$email=trim(htmlspecialchars($_POST['email']));
	$poruka=trim(htmlspecialchars($_POST['poruka']));
	if(mail("nemanjaneskovic@gmail.com",$email,$poruka))
		header('Location:../categories/contact.php?message=true');
	else print_r(error_get_last());

}else header('Location:../index.php');





?>