<?php
require("PDO.php");
require("ch_cat.php");
$category=0;
if(isset($_GET['category'])){
	if($_GET['category']==1||$_GET['category']==2||$_GET['category']==3||$_GET['category']==4||$_GET['category']==5||$_GET['category']==6||$_GET['category']==7||$_GET['category']==8){
		$category=$_GET['category'];
	}else $category=1;
}else $category=1;
$cat_result=$kon->query("SELECT vest_eng.sifra,vest_eng.naslov,vest_eng.tekst,vest_eng.status,vest_eng.vreme,vest_eng.slika,kategorija.naziv AS kategorija,novinar.ime FROM vest_eng INNER JOIN kategorija ON vest_eng.kategorija=kategorija.sifra INNER JOIN novinar ON vest_eng.autor=novinar.sifra WHERE vest_eng.kategorija=$category AND vest_eng.status=1 ORDER BY vest_eng.sifra DESC");


	

?>