<?php
class Mng_comm{
	private $name;
	private $content;
	private $secret_num;

	public function __construct($content,$ime,$sec){
		$this->content=$content;
		$this->name=$ime;
		$this->secret_num=$sec;
	}

	public function show(){
		echo '<li class="list-group-item align-items-center">
                                        <div> <h2>'.$this->name.'</h2>
										<p>'.$this->content.'</p>
                                         </div>
                                        <div class="btn-group ml-auto">
                                        <form action="../../pristup/comm.php" method="post">
                                        <input type="hidden" value="'.$this->secret_num.'" name="hdn">
                                            <button type="submit" name="grant" class="btn btn-sm btn-outline-light" value="Odobri">Odobri</button></form>
                                            <form action="../../pristup/comm.php" method="post">
                                            <input type="hidden" value="'.$this->secret_num.'" name="hdn">
                                            <button type="submit" name="grant" value="Obrisi" class="btn btn-sm btn-outline-light">
                                                <i class="far fa-trash-alt"></i>
                                                
                                            </button></form>
                                        </div>
                                    </li>';
	}
}

?>