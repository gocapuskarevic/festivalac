<?php
class Grant_news{
	private $title;
	private $autor;
	private $content;
	private $sifra;
	private $datum;
	private $image_path="../images/";

	public function __construct($tit,$au,$con,$sif,$da,$img){
		$this->title=$tit;
		$this->autor=$au;
		$this->content=$con;
		$this->sifra=$sif;
		$this->datum=$da;
		$this->image_path.=$img;
	}

	public function show_news(){
		echo '<form method="post" action="../pristup/granting_news.php">
						<h3>'.$this->title.'</h3>
						<img src="'.$this->image_path.'" style="width:500px;height:350px;" alt="Slika vesti">
					<p><i>'.$this->autor.'</i></p>
					<p>'.$this->content.'</p>
					<input type="hidden" value="'.$this->sifra.'" name="hdn">
					<input type="submit" name="grant_news" value="Odobri"></form>';
	}
}
















?>