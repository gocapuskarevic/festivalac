<?php
if(isset($_GET['num'])){
	require_once('PDO.php');
	$sifra=$_GET['num'];
	$galerija=$kon->query("SELECT * FROM slike_galerija WHERE folder=$sifra");
	$pr0=$kon->query("SELECT naziv_foldera,autor FROM galerija WHERE sifra_g=$sifra");
	$pr0=$pr0->fetch_assoc();
	$pr=str_replace('-', '/',$pr0['naziv_foldera']);
	$pr1=str_replace('_','.',$pr);

	
	$sa_strane=$kon->query("SELECT naziv_foldera,sifra_g FROM galerija WHERE sifra_g!=$sifra ORDER BY sifra_g DESC LIMIT 5");

	
}else header('Location:../index.php');



?>