<?php
require('PDO.php');
if(!empty($_GET['trazise'])){
	$vrednost=strtolower($_GET['trazise']);
		$srch=$kon->query("SELECT vest_eng.sifra,vest_eng.naslov,vest_eng.tekst,vest_eng.slika FROM vest_eng INNER JOIN tag_vest_eng ON tag_vest_eng.vest_eng=vest_eng.sifra INNER JOIN tagovi ON tagovi.sifra=tag_vest_eng.tag WHERE (tag_vest_eng.tag=$vrednost OR tagovi.imetaga LIKE '%$vrednost%') AND vest_eng.status=1");
	}/*else{
		$srch=$kon->query("SELECT vest.sifra,vest.naslov,vest.tekst,vest.slika FROM vest INNER JOIN tag_vest ON tag_vest.vest=vest.sifra INNER JOIN tagovi ON tagovi.sifra=tag_vest.tag WHERE (tag_vest.tag='$vrednost' OR tagovi.ime_taga LIKE '%$vrednost%' OR vest.naslov LIKE '%$vrednost%' OR vest.naslov LIKE '%$vrednost%') AND vest.status=1");*/

else header('Location:../index.php');




?>