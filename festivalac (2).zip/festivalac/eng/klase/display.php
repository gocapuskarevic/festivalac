<?php
class Display{
	protected $title;
	protected $content;
	protected $image_path="../images/";
	protected $date;
	protected $secret;
	protected $selected="categories/selected-news.php"."?number=";

	public function __construct($title,$content,$img_p,$date,$sec){
		$this->title=$title;
		$this->content=$content;
		$this->image_path.=$img_p;
		$this->date=$date;
		$this->secret=$sec;
		$this->selected.=$sec;
	}

	public function latest_news(){
		echo '<a href="'.$this->selected.'"><div id="hold_wrap"><img src="'.$this->image_path.'" alt="Najnovija vest" class="transform"></a>
				<div id="wrap_main_title"><h1><a href="'.$this->selected.'">'.$this->title.'</a></h1></div></div>';

	}

/*
	public function main_show(){
		$short=substr($this->content,0,150);
		echo '<div class="col-md-4 col-sm-12 left"><article class="visina"><a href="'.$this->selected.'"><img src="'.$this->image_path.'" alt="Slika vesti" class="transform velicina" style:"max-height:145px;></a>
		<div class="set_height_h"><h3>'.substr($this->title,0,16).'...</h3></div>
		<div class="set_height_p"><p>'.$short.'</p></div>
		
		<a href="'.$this->selected.'" class="nece">Pročitaj sve <i class="fa fa-angle-right"></i></a></article></div>';
	}
*/
	public function aside_show(){
		echo '<article><img src="'.$this->image_path.'" alt="Slika vesti" class="float-left">
				<h3 class="no-top-margin"><a href="'.$this->selected.'">'.$this->title.'</a></h3></article>';

	}
	public function izvestaj(){
			echo '<div class="col-md-4 col-sm-12"><div class="uzana"><article><a href="categories/selected-news.php?number='.$this->secret.'"><div><img src="'.$this->image_path.'" alt="Slika vesti" class="transform velicina"></a><div class="set_height_h"><h4><a href="categories/selected-news.php?number='.$this->secret.'">'.$this->title.'</a></h4></div></div></article></div></div>';
	}
	

	public function footer_news(){
		echo '<article>				
			  <img src="'.$this->image_path.'" alt="Slika vesti" class="float-left">
			  <h4 class="no-top-margin"><a href="'.$this->selected.'">'.$this->title.'</a></h4>
			  <p>'.substr($this->date,0,10).'</p></article>';
	}
}

?>