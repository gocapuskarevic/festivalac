<?php
require_once('PDO.php');
$sve=$kon->query("SELECT naziv_foldera,sifra_g FROM galerija ORDER BY sifra_g DESC");





/*
if(!isset($_GET['number'])){
	$sve=$kon->query("SELECT slike_galerija.naziv_slike,slike_galerija.odakle,galerija.autor,galerija.naziv_foldera FROM slike_galerija INNER JOIN galerija ON galerija.sifra_g=slike_galerija.folder ORDER BY galerija.sifra_g DESC");
}//$sa_strane->fetch_assoc()['sifra_g']"";
else{
	$num=$_GET['number'];
	$sve=$kon->query("SELECT slike_galerija.naziv_slike,slike_galerija.odakle,galerija.autor,galerija.naziv_foldera FROM slike_galerija INNER JOIN galerija ON galerija.sifra_g=slike_galerija.folder WHERE slike_galerija.folder=".$num."");
}

echo $sve->num_rows;


*/





?>