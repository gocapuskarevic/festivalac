<?php
require('PDO.php');
require('selected.php');
if(is_numeric($_GET['number'])){
	$res=$kon->query('SELECT vest_eng.sifra AS sifra,vest_eng.naslov,vest_eng.tekst,vest_eng.vreme,vest_eng.kategorija,vest_eng.slika,novinar.ime FROM vest_eng INNER JOIN novinar ON novinar.sifra=vest_eng.autor WHERE vest_eng.status=1 AND vest_eng.sifra='.$_GET['number'].'');
	$tagovi=$kon->query("SELECT tagovi.imetaga,tagovi.sifra FROM tagovi INNER JOIN tag_vest_eng ON tag_vest_eng.tag=tagovi.sifra WHERE tag_vest_eng.vest_eng=".$_GET['number']."");
	if(!$tagovi) echo $kon->error;
	
	$kon->query("CALL povecaj(".$_GET['number'].")");

}else header('Location:../index.php');
















?>