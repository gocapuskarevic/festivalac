<?php
$imali=$kon->query("SELECT sifra_g FROM galerija WHERE vest=".$vest['sifra']."");
if($imali->num_rows>0){
	$broj=$imali->fetch_assoc()['sifra_g'];
	echo '<button class="btn btn-danger"><a href="selected_gallery.php?num='.$broj.'" style="color:white;">POGLEDAJ GALERIJU</a></button>';
}else echo "";



?>