<?php
require_once('PDO.php');
$svi_komentari=$kon->query("SELECT * FROM komentari_eng WHERE vest_eng=".$_GET['number']." AND odobri=1");
//var_dump($res->fetch_assoc());















?>