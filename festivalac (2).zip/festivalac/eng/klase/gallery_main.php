<?php
require_once('PDO.php');
$gallery=$kon->query("SELECT galerija.sifra_g,galerija.naziv_foldera FROM galerija ORDER BY galerija.sifra_g DESC LIMIT 3");




?>