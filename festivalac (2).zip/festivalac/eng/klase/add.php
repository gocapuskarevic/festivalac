<?php
$imeSlike=$_FILES['image']['name'];//ovde ide ime inputa koji je dole
if(move_uploaded_file($_FILES['image']['tmp_name'], $imeSlike))
	echo "ok";
else echo "no";


<input type="file" name="image" accept=".jpg,.jpeg,.gif,.png">
?>