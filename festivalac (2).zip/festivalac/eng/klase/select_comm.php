<?php
require('PDO.php');
require('mng_comm.php');
$all_comments=$kon->query("SELECT * FROM komentari WHERE odobri=0");
//print_r($all_comments->fetch_assoc());
if($all_comments->num_rows>0){
	while($row=$all_comments->fetch_assoc()){
		$comment=new Mng_comm($row['sadrzaj'],$row['ime'],$row['sifra']);
		$comment->show();
	}
}else
echo "<h2>Nema novih komentara</h2>";





















?>