<?php
require_once('PDO.php');
$novinari=$kon->query("SELECT novinar.mail FROM novinar");
$tmp=$kon->query("SELECT vest.sifra FROM vest WHERE vest.status=0 ORDER BY vest.sifra DESC");
$last_id=$tmp->fetch_assoc()['sifra'];

$niz_n=array();
while($tmp=$novinari->fetch_array())
	array_push($niz_n,$tmp['mail']);
if(isset($_POST['submit'])&&isset($_SESSION['sign'])&&in_array($_SESSION['sign'],$niz_n)){
	
	if(is_numeric($_POST['number'])&&($_POST['number']<=$last_id)){
		$vest=$kon->query("SELECT * FROM vest WHERE sifra=".$_POST['number']."");
		$finall_vest=$vest->fetch_assoc();
	}else header("Location:../../index.php");

}else header("Location:../index.php");

?>