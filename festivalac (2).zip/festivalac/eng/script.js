var start=0;
var limit=7;
function ucitaj_jos(){
	var ajax = new XMLHttpRequest();
	ajax.open("GET", "klase/load_more.php?start=" + start + "&limit=" + limit, true);
    ajax.send();
        ajax.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
            	var data=JSON.parse(this.responseText);
            	var prikaz="";
            	for(var a=0;a<data.length;a++){
            		if(a===0) {continue;}
            		prikaz+='<div class="col-md-4 col-sm-12 left"><article class="height-min"><a href="categories/selected-news.php?number='+data[a].sifra+'"><img src="../images/'+data[a].slika+'" alt="Slika vesti" class="transform velicina"></a><div class="set_height_h"><h4><a href="categories/selected-news.php?number='+data[a].sifra+'">'+data[a].naslov+'</a></h4></div></article></div>';

//document.getElementById("najcitanije").innerHTML = this.responseText; } };
				}
				document.getElementById('najcitanije').innerHTML=prikaz;
			}
		}
        
        limit+=6;
}
window.onload=ucitaj_jos();