<?php include('../include/header.html');?>
<style>
	input[type=text]:focus,input[type=password]:focus,input[type=email]:focus,input[type=submit]:focus{
	box-shadow: 0 0 5px #9d9d9d;
	border: 1px solid #9d9d9d;
	}
#user_comm:focus{

	box-shadow: 0 0 5px #9d9d9d;
	border: 1px solid #9d9d9d;
	outline: none;
}</style>
<link rel="stylesheet" href="lightbox/src/hes-gallery.css">
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/sr_RS/sdk.js#xfbml=1&version=v3.3"></script>

<script src="lightbox/src/hes-gallery.js"></script>
<script>
			function salji(){
				var vr=document.getElementsByName('field')[0].value;
				window.location.href="search.php?trazise="+vr
			}
		</script>
</head>
<body>
	<?php
		
	if(isset($_GET['ann'])){
		switch($_GET['ann']){
			case 'no':
			echo "<script>alert('Došlo je do greške,pokušajte ponovo da pošaljete komentar')</script>";
			break;
			case 'yes':
			echo "<script>alert('Uspešno ste poslali komentar! Hvala!')</script>";
			break;
		}
	}
	 ?>

		<div class="container-fluid">
			
			<div class="row">
				<header>
				<div class="col-sm-12">
					 <a href="../index.php" class="no-pad"><img src="../logo_mali.png"></a>
					<nav class="navbar navbar-inverse" style="margin-left: 40px;">

						<button class="navbar-toggle pull-left" data-toggle="collapse" data-target=".navHeaderCollapse">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>

						<div class="collapse navbar-collapse navHeaderCollapse">
						  
						    <ul class="nav navbar-nav navbar-left">
						    	
						      <li ><a href="../index.php">VESTI</a></li>
						        <li><a href="category.php?category=2">IZVEŠTAJI</a></li>
						      	<li id="taj"><a href="category.php?category=4">ČLANCI</a>
						      		<ul class="nav navbar-nav padajuci">
						      			<li><a href="category.php?category=5">U fokusu</a>
						      			<li><a href="category.php?category=6">Top liste</a>
						      			<li><a href="category.php?category=7">Must-See</a>
						      		</ul>
						      </li></li>
						      <li><a href="category.php?category=3">INTERVJUI</a></li>
						      <li><a href="gallery.php">GALERIJA</a></li><li style="margin-top: 7px;"><input type="text" name="field" class="form-control" style="display:inline;" placeholder="Pretraži vesti..." maxlength="30"></li>
						      <li><a href="#" onclick="salji();"><i class="fa fa-search"></i></a></li>
						      
						    </ul>
						    </div><!--ovaj div drzi sve za hamburger meni posle-->

						    <div class="top-right">
						    	<a href=""><i class="fab fa-instagram" title="Instagram"></i></a>
						    	<a href=""><i class="fa fa-twitter-square" title="Twiter"></i></a>
						    	<a href="https://www.facebook.com/nemanja.neskovic.73"><i class="fa fa-facebook-square" title="Facebook"></i></a>
						    	<a href="../eng/index.php"><img src="../flag.png" style="width:35px;height: 30px;"></a>
						    </div>
						</nav>
						</div>
					</header>
			
			</div>
			<div class="row">
			<div class="col-md-10 col-md-offset-1 col-sm-12 centar">
				<div id="rezultat">
				<div class="col-sm-12">
					<main style="overflow: hidden;">
							<div class="hes-gallery" data-wrap="true" data-img-count="3" style="overflow: hidden;">

							
							<?php
							require('../klase/search_images_gallery.php');
							if($sve->num_rows>0){
								$brojac=0;
							while($gall=$sve->fetch_assoc()){
								$sl=$gall['sifra_g'];
								$pr=str_replace('-', '/',$gall['naziv_foldera']);
								$pr1=str_replace('_','.',$pr);
								$slika=$kon->query("SELECT naziv_slike,odakle FROM slike_galerija WHERE folder=$sl LIMIT 1");
								$slika=$slika->fetch_assoc();
								if($slika['odakle']==0) $prikaz='<div class="uzana">'.$slika['naziv_slike'].'</div>';
								else
									$prikaz='<div><img src="../gallery/'.$gall['naziv_foldera'].'/'.$slika['naziv_slike'].'"></div>';
									
								if($brojac<2)
									echo '<div class="dve_galerije">'.$prikaz.'<h3><a href="selected_gallery.php?num='.$gall['sifra_g'].'">'.$pr1.'</a></h3></div>';
								else echo '<div class="sve_galerije">'.$prikaz.'<h3 ><a href="selected_gallery.php?num='.$gall['sifra_g'].'">'.$pr1.'</a></h3></div>';
								$brojac++;
							}
							

						}else die("Nema galerije");
					
						 ?>
						</div>
	
						</main>
					</div>
					</div><!--ovo je div koji sadrzi odabranu galeriju-->
					
			
			</div><!--ovo je div koji sadrzi sve-->
			
			</div><!--ovo je div koji je row-->
		</div>
			<div class="smoot"><a href="#"><i class="fas fa-angle-up"></i></a></div>
	<script type="text/javascript">
	window.onscroll = function() {myFunction()};
function myFunction() {
  if (document.documentElement.clientHeight > 350) {
    document.getElementsByClassName("smoot")[0].style.display = "block";
  }else if(document.documentElement.clientHeight < 350)document.getElementsByClassName("smoot")[0].style.display = "none";
}
		
	</script>
	
<?php include('../include/footer.html');?>
	
					<!--AKO BUDU TREBALI KOMENTARI
					<h2>Ostavite komentar</h2>
					<form action="../klase/new_comm.php" method="post" class="form-group">
						<label for="user_name">Ime:</label>
							<input type="text" name="user_name" id="user_name" class="form-control" maxlength="50" required>
							<label for="user_comm">Komentar:</label>
							<textarea class="form-control" name="user_comm" id="user_comm" maxlength="950" required></textarea><br>
							<input type="hidden" name="hdn" value="<?php //echo $_GET['number'] ?>">
							<input type="submit" name="send_comm" value="Pošalji komentar" class="form-control">
					</form>
				</article>
				<article id="comments">
						<h2>Komentari</h2>
						<?php /*include('../klase/news_comm_aded.php');
						
						if($svi_komentari->num_rows>0){
							while($jedan=$svi_komentari->fetch_assoc()){
								echo "<section>
							<p><b>".$jedan['ime'].": </b>".$jedan['sadrzaj']."</p>
							<p><i>Datum: ".$jedan['datum']."</i></p>
						</section>";
							}
						}else echo "<div class='col-sm-12'><h3 stye='font-size:50px;'>Ova vest još nema komentare</h3></div>"; */?>
						AKO BUDU TREBALI KOMENTARI


					</article> div sa komentarima čitalaca-->


<!--

