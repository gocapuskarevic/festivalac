<?php
include('../include/header.html');
if(isset($_GET['message'])) echo "<script>alert('Poruka je poslata,očekujte brz odgovor!');</script>";
?>
</head>
<body>
	<div class="container-fluid">
		<div class="row">
			<header>
				<div class="col-sm-12">
					<a href="../index.php" class="no-pad"><img src="../logo_mali.png"></a>
					<nav class="navbar navbar-inverse" style="margin-left: 40px;">

						<button class="navbar-toggle pull-left" data-toggle="collapse" data-target=".navHeaderCollapse">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>

						<div class="collapse navbar-collapse navHeaderCollapse">
						  
						    <ul class="nav navbar-nav navbar-left">
						    	
						      <li ><a href="../index.php">VESTI</a></li>
						        <li><a href="category.php?category=2">IZVEŠTAJI</a></li>
						      <li><a href="category.php?category=4">ČLANCI</a>
						      <ul class="nav navbar-nav padajuci">
						      			<li><a href="category.php?category=5">U fokusu</a>
						      			<li><a href="category.php?category=6">Top liste</a>
						      			<li><a href="category.php?category=7">Must-See</a>
						      		</ul></li>
						      <li><a href="category.php?category=3">INTERVJUI</a></li>
						      <li><a href="gallery.php">GALERIJA</a></li>
						     
						      <li style="margin-top:8px;">
						   			<input type="text" name="field" class="form-control" style="display:inline;" placeholder="Pretraži vesti..." maxlength="30"></li>
						      <li><a href="#" onclick="salji();"><i class="fa fa-search"></i></a></li>
						      
						    </ul>
						    </div><!--ovaj div drzi sve za hamburger meni posle-->

						    <div class="top-right">
						    	<a href=""><i class="fab fa-instagram" title="Instagram"></i></a>
						    	<a href=""><i class="fa fa-twitter-square" title="Twiter"></i></a>
						    	<a href="https://www.facebook.com/nemanja.neskovic.73"><i class="fa fa-facebook-square" title="Facebook"></i></a>
						    	<a href="../eng/index.php"><img src="../flag.png" style="width:35px;height: 30px;"></a>
						    </div>
						</nav>
						</header>
		</div>

		<div class="col-sm-12 col-md-4 col-md-offset-4" style="text-align: justify;">
			<h1 style="text-align: center;">Kontakt strana</h1>
			<p>Slobodno nam se obratite</p>
			<div class="form-group">
				<form method="post" action="../klase/poruka.php">
					<label for="ime">Vaše ime</label>
					<input type="text" name="ime" id="ime" class="form-control" maxlength="60" placeholder="Polje je obavezno" required>
					<label for="email">Vaš email</label>
					<input type="email" name="email" id="email" class="form-control" maxlength="60" placeholder="Polje je obavezno" required>
					<label for="poruka">Poruka</label>
					<textarea class="form-control" id="poruka" name="poruka">Slobodno nam pišite</textarea><br><br>
					
					<input type="submit" class="form-control" name="por" value="Pošalji poruku">

				</form>
			</div>
			
		</div>
	</div>
</body>


<?php
include('../include/footer.html');
?>