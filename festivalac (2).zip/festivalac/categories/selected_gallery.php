<?php include('../include/header.html');?>
<style>
	input[type=text]:focus,input[type=password]:focus,input[type=email]:focus,input[type=submit]:focus{
	box-shadow: 0 0 5px #9d9d9d;
	border: 1px solid #9d9d9d;
	}
#user_comm:focus{

	box-shadow: 0 0 5px #9d9d9d;
	border: 1px solid #9d9d9d;
	outline: none;
}</style>
<link rel="stylesheet" href="lightbox/src/hes-gallery.css">
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/sr_RS/sdk.js#xfbml=1&version=v3.3"></script>

<script src="lightbox/src/hes-gallery.js"></script>
<script>
			function salji(){
				var vr=document.getElementsByName('field')[0].value;
				window.location.href="search.php?trazise="+vr
			}
		</script>
</head>
<body>


		<div class="container-fluid">
			<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/sr_RS/sdk.js#xfbml=1&version=v3.3"></script>
			<div class="row">
				<header>
				<div class="col-sm-12">
					 <a href="../index.php" class="no-pad"><img src="../logo_mali.png"></a>
					<nav class="navbar navbar-inverse" style="margin-left: 40px;">

						<button class="navbar-toggle pull-left" data-toggle="collapse" data-target=".navHeaderCollapse">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>

						<div class="collapse navbar-collapse navHeaderCollapse">
						  
						    <ul class="nav navbar-nav navbar-left">
						    	
						      <li ><a href="../index.php">VESTI</a></li>
						        <li><a href="category.php?category=2">IZVEŠTAJI</a></li>
						      	<li id="taj"><a href="category.php?category=4">ČLANCI</a>
						      		<ul class="nav navbar-nav padajuci">
						      			<li><a href="category.php?category=5">U fokusu</a>
						      			<li><a href="category.php?category=6">Top liste</a>
						      			<li><a href="category.php?category=7">Must-See</a>
						      		</ul>
						      </li></li>
						      <li><a href="category.php?category=3">INTERVJUI</a></li>
						      <li><a href="gallery.php">GALERIJA</a></li><li style="margin-top: 7px;"><input type="text" name="field" class="form-control" style="display:inline;" placeholder="Pretraži vesti..." maxlength="30"></li>
						      <li><a href="#" onclick="salji();"><i class="fa fa-search"></i></a></li>
						      
						    </ul>
						    </div><!--ovaj div drzi sve za hamburger meni posle-->

						    <div class="top-right">
						    	<a href=""><i class="fab fa-instagram" title="Instagram"></i></a>
						    	<a href=""><i class="fa fa-twitter-square" title="Twiter"></i></a>
						    	<a href="https://www.facebook.com/nemanja.neskovic.73"><i class="fa fa-facebook-square" title="Facebook"></i></a>
						    	<a href="../eng/index.php"><img src="../flag.png" style="width:35px;height: 30px;"></a>
						    	
						    </div>
						</nav>
						</div>
					</header>
					


			<div class="col-md-10 col-md-offset-1 col-sm-12 centar">
				<div class="row">
				<div class="col-sm-12 col-md-8">
					<main>
							<div class="hes-gallery" data-wrap="true" data-img-count="3">
								
							
							<?php
							require('../klase/jedna_galerija.php');
							//print_r($sve);
							echo "<h1>".$pr1."</h1>";
							echo '<div><p>Autor : '.$autor=$pr0['autor'].'</p></div>';
							echo '<div class="fb-like" data-href="https://festivalac.com" data-width="" data-layout="button_count" data-action="like" data-size="small" data-show-faces="false" data-share="true"></div><br>';
							if($galerija->num_rows>0){
								while($slika=$galerija->fetch_assoc()){
									if($slika['odakle']==0) $prikaz='<div class="gallery_images">'.$slika['naziv_slike'].'</div>';
								else{
										
										$prikaz='<div class="gallery_images"><img src="../gallery/'.$pr0['naziv_foldera'].'/'.$slika['naziv_slike'].'"></div>';
										}
								echo $prikaz;
								}
									

							}else die("Nema galerije");

						 ?>
						</div>
	
						</main>
					</div>
					<div class="col-sm-12 col-md-4">
						<aside style="margin-left: 15px;clear:both;">
							<section>
							<h2>Ostale galerije</h2>
							<div><?php
								while($as=$sa_strane->fetch_assoc()){
									$trenutna=$as['sifra_g'];
									$joj=$kon->query("SELECT slike_galerija.naziv_slike,slike_galerija.odakle FROM slike_galerija WHERE slike_galerija.folder=$trenutna LIMIT 2");
									$prikaz="";
									while($slike=$joj->fetch_assoc()){
										if($slike['odakle']==0) $prikaz.=$slike['naziv_slike'];
										else{
										
											$prikaz.='<img src="../gallery/'.$as['naziv_foldera'].'/'.$slike['naziv_slike'].'">';
										}
									}
									
										$f=str_replace('-', '/',$as['naziv_foldera']);
										$prikaz_koji=str_replace('_','.',$f);
										$konacni='<article><div class="small_gallery">'.$prikaz.'
											<h4><a href="selected_gallery.php?num='.$as['sifra_g'].'">'.$prikaz_koji.'</a></h4></div></article>';
									
									echo $konacni;

								}
									?>
							</div>
							</section>
						
						</aside>
				
					</div><!--ovo je div koji sadrzi aside,ostale gall-->
					</div>
					</div><!--ovo je div koji sadrzi odabranu galeriju-->
					
			


			</div>

	<div class="smoot"><a href="#"><i class="fas fa-angle-up"></i></a></div>
	<script type="text/javascript">
	window.onscroll = function() {myFunction()};
function myFunction() {
  if (document.documentElement.clientHeight > 350) {
    document.getElementsByClassName("smoot")[0].style.display = "block";
  }else if(document.documentElement.clientHeight < 350)document.getElementsByClassName("smoot")[0].style.display = "none";
}
		
	</script>
<?php include('../include/footer.html');?>
	
