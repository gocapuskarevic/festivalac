function izlistaj(status){
    var staje="OBJAVLJENE";
       switch(status){
        case '1':
        staje="OBJAVLJENE";
        break;
        case '4':
        staje="RASPOREĐENE";
        break;
        case '3':
        staje="OBRISANE";
        break;
        case '0':
        staje="NA ČEKANJU";
        break;
        case '2':
        staje="DRAFT"
        break;
    }
    document.getElementById('odabrano').innerHTML=staje;
    var ajax2 = new XMLHttpRequest();
    ajax2.open("GET", "ajax/m_news.php?status=" + status, true);
    ajax2.send();
     ajax2.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
        
                var data2=JSON.parse(this.responseText);
                var prikaz2="<table class='table table-responsive-sm'>";
                prikaz2+="<tr><th>Opcije</th><th>Naslov</th><th>Status</th><th>Zadnja izmena</th><th>Viđeno</th></tr>";
               var promeni="";
                    for(var a=0;a<data2.length;a++){
                        if(data2[a].status!=1) promeni='<a href="izmena.php?number='+data2[a].sifra+'">Izmeni</a>';
                            prikaz2+="<tr>";
                            prikaz2+='<td class="w-10 mali"><a href="'+ispis(data2[a].status)+data2[a].sifra+'">Pregledaj</a><br>'+promeni+'</td>';
                            prikaz2+='<td class="w-40">'+data2[a].naslov+'</a></td>';
                            prikaz2+='<td class="w-20">'+data2[a].status+'</a></td>';
                            prikaz2+='<td class="w-10">'+data2[a].vreme+'</td>';
                            prikaz2+='<td class="w-10">'+data2[a].klik+'</td>';
                            prikaz2+="</tr>";
                    
                        }
                            prikaz2+="</table>";
                            document.getElementById('sve_vesti').innerHTML=prikaz2;
                        }
                        
                }
                
        }



function ispis(kategorija){
    var pise;
    if(kategorija==1)
        return "../../categories/selected-news.php?number=";
    else return "pregled_mod_news.php?see=";
}

window.onload=izlistaj(1);