<?php
session_start();
if(!isset($_SESSION['sign']))
header('Location:../../index.php');
include('../../include/header.html');
require_once('../../klase/PDO.php');
require_once('../../klase/selected.php');
$master=$kon->query("SELECT sifra,master FROM novinar WHERE mail='".$_SESSION['sign']."'");
$master=$master->fetch_assoc();
if(isset($_GET['see'])&&is_numeric($_GET['see'])){
	$sifra=$_GET['see'];
	$vest_mod=$kon->query("SELECT  vest.sifra,vest.naslov,vest.tekst,vest.slika,vest.status,vest.vreme,novinar.ime FROM vest INNER JOIN novinar ON novinar.sifra=vest.autor WHERE vest.sifra=$sifra");
}else header('Location:../../index.php');
if(isset($_GET['ann'])){
    $notice=$_GET['ann'];
    switch($notice){
        case 'draft':
        echo "<script>alert('Vest je sačuvana kao draft!')</script>";
        break;
        case 'vreme':
        echo "<script>alert('Odredite prvo vreme za objavu!')</script>";
        break;
        case 'raspored':
        echo "<script>alert('Vest je spremna i čeka vreme objave!')</script>";
        break;
        case 'no':
        echo "<script>alert('Ništa se nije desilo!')</script>";
        break;
        case 'objavljeno':
        echo "<script>alert('Vest je objavljena!')</script>";
        break;
        case 'obrisano':
        echo "<script>alert('Uspešno obrisana vest!')</script>";
    }
}
?>
<style>
	p > img{
		max-width: 100%;
	}
	#float_right{
		float:right;
	}

</style>
</head>

<body>
	

		<div class="container-fluid">
			
			<div class="row">
				<header>
				<div class="col-sm-12">
					<nav class="navbar navbar-inverse">
						  
						    <ul class="nav navbar-nav">
						      <li><a href="index_vesti.php">Vrati se nazad</a></li>
						  
						      
						    </ul>

						</nav>
						</header>
			
			</div>
			<div class="col-md-10 col-md-offset-1 col-sm-12 ">
				<div class="col-sm-12 col-md-8">
					<main><?php
					if($vest_mod->num_rows>0){
						$vest=$vest_mod->fetch_assoc();

						$status=$vest['status'];
						switch ($status) {
							case '0':
								$opcije='<input type="submit" class="btn btn-primary mb-2" name="draft" value="Sačuvaj u draft">
								<div id="float_right">
								<label for="meeting-time">Odredi vreme :</label>
								<input type="datetime-local" id="meeting-time" name="time">
						       <input type="submit" class="btn btn-primary mb-2" name="rasporedi" value="Rasporedi"></div>
						       <br><br>
						       <input type="submit" class="btn btn-primary mb-2" name="objavi" value="Objavi odmah">
								<div id="float_right">
								<input type="submit" class="btn btn-primary mb-2" name="obrisi" value="Obriši">
								';
								break;
							case '1':
								$opcije='<input type="submit" class="btn btn-primary mb-2" name="draft" value="Sačuvaj u draft">
								<div id="float_right">';
						       break;
						       case '2':
								$opcije='
								<div id="float_right"><label for="meeting-time">Odredi vreme :</label>
								<input type="datetime-local" id="meeting-time" name="time">
						       <input type="submit" class="btn btn-primary mb-2" name="rasporedi" value="Rasporedi"></div>
						       <br><br>
						       <input type="submit" class="btn btn-primary mb-2" name="objavi" value="Objavi odmah">
								<div id="float_right">
								<input type="submit" class="btn btn-primary mb-2" name="obrisi" value="Obriši">
								<div id="float_right">';
								break;
								 case '3':
								$opcije='<input type="submit" class="btn btn-primary mb-2" name="draft" value="Sačuvaj u draft">';
								break;
								  case '4':
								$opcije='
								<div id="float_right"><label for="meeting-time">Odredi vreme :</label>
								<input type="datetime-local" id="meeting-time" name="time">
						       <input type="submit" class="btn btn-primary mb-2" name="rasporedi" value="Rasporedi"></div>
						       <br><br>
						       <input type="submit" class="btn btn-primary mb-2" name="objavi" value="Objavi odmah">
								<div id="float_right">
								<input type="submit" class="btn btn-primary mb-2" name="obrisi" value="Obriši">
								<div id="float_right">';
								break;
								 
							
						}
						echo '<form method="post" action="../../pristup/raspored.php"><input type="hidden" name="sifra" class="form-control" value="'.$vest['sifra'].'">';
						$obj=new Selected($vest['naslov'],$vest['ime'],$vest['vreme'],$vest['slika'],$vest['tekst']);
						$obj->show_fast($vest['slika']);
						if($master['sifra']==$master['master'])
							echo '<div class="form-group">
								
								'.($master['sifra']==$master['sifra'])?$opcije : ''.'
						       </div>
						</form>
					</div>';
						
					}else die("Ne postoji vest po zadatom kriterijumu");
						
				?>



			</main><!--ovo je div koji sadrzi odabranu vest-->

			</div>
			<div class="col-sm-12 col-md-4">
				

			</div>
			</div>
		
			
		</div>
	</div>



</body>
</html>