<?php
require('../../../klase/PDO.php');

$si=$_GET['sifra'];

$post="SELECT vest_eng.naslov,vest_eng.klik,vest_eng.vreme,vest_eng.status,vest_eng.sifra,kategorija.naziv FROM vest_eng INNER JOIN kategorija ON kategorija.sifra=vest_eng.kategorija WHERE vest_eng.autor=$si ORDER BY vest_eng.sifra DESC"; 

$posti=$kon->query($post);

	
		$niz=array();
		while($postovi=$posti->fetch_assoc()){
			$niz[]=$postovi;
		}

echo json_encode($niz);






?>