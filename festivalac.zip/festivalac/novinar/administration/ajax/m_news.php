<?php
session_start();
require('../../../klase/PDO.php');
$status=$_GET['status'];
if(isset($_SESSION['sign'])){
	$sesija=$_SESSION['sign'];
	$nov=$kon->query("SELECT sifra FROM novinar WHERE mail='$sesija'");
	$novinar=$nov->fetch_assoc()['sifra'];
	$vesti=$kon->query("SELECT vest.sifra,vest.status,vest.naslov,vest.vreme,vest.klik FROM vest WHERE vest.autor=$novinar AND vest.status=$status");
	$niz=array();
	
		while($vest=$vesti->fetch_assoc()){
			$niz[]=$vest;
		}
		echo json_encode($niz);
	



}else header('Location:../../../index.php');




?>