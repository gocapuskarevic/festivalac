<?php
session_start();
require('../../../klase/PDO.php');
$status=$_GET['status'];
if(isset($_SESSION['sign'])){
	$sesija=$_SESSION['sign'];
	$nov=$kon->query("SELECT sifra FROM novinar WHERE mail='$sesija'");
	$novinar=$nov->fetch_assoc()['sifra'];
	$vesti=$kon->query("SELECT vest_eng.sifra,vest_eng.status,vest_eng.naslov,vest_eng.vreme,vest_eng.klik FROM vest_eng WHERE vest_eng.autor=$novinar AND vest_eng.status=$status");
	$niz=array();
	
		while($vest=$vesti->fetch_assoc()){
			$niz[]=$vest;
		}
		echo json_encode($niz);
	



}else header('Location:../../../index.php');




?>