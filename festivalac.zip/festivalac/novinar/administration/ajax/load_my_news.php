<?php
require('../../../klase/PDO.php');

$si=$_GET['sifra'];

$post="SELECT vest.naslov,vest.klik,vest.vreme,vest.status,vest.sifra,kategorija.naziv FROM vest INNER JOIN kategorija ON kategorija.sifra=vest.kategorija WHERE vest.autor=$si ORDER BY vest.sifra DESC"; 

$posti=$kon->query($post);

	
		$niz=array();
		while($postovi=$posti->fetch_assoc()){
			$niz[]=$postovi;
		}

echo json_encode($niz);






?>