<?php
require_once('../../klase/PDO.php');
	$galerija=$kon->query("SELECT sifra_g,naziv_foldera FROM galerija ORDER BY sifra_g DESC");


?>