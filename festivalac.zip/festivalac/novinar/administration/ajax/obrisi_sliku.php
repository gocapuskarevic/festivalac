<?php
require('../../../klase/PDO.php');
$folder=$_GET['folder'];
$slika=$_GET['slika'];

if($kon->query('DELETE FROM slike_galerija WHERE folder='.$folder.' AND naziv_slike="'.$slika.'"')){

	$slike=$kon->query('SELECT folder,naziv_slike,odakle,naziv_foldera FROM slike_galerija INNER JOIN galerija ON galerija.sifra_g=slike_galerija.folder WHERE folder='.$folder.'');
	if($slike->num_rows<1){
		$kon->query("DELETE FROM galerija WHERE sifra_g=$folder");
	}



	$array=array();
	while($row=$slike->fetch_assoc())
		$array[]=$row;
	

	echo json_encode($array);

}else echo $kon->error;


?>