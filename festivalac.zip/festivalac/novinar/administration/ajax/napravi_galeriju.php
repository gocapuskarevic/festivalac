<?php
session_start();
if(isset($_SESSION['sign'])){
		require('../../../klase/PDO.php');
		$ime=$kon->query("SELECT ime from novinar WHERE mail='".$_SESSION['sign']."'");
		$autor=$ime->fetch_assoc()['ime'];
		if(isset($_GET['naslov'])){
			$naslov=trim($_GET['naslov']);
			$folder1=str_replace('/', '-', $naslov);
			$folder=str_replace('.', '_', $folder1);
			$vest=$_GET['vest'];
			$vec_postoje=$kon->query("SELECT naziv_foldera FROM galerija");
			$galerija=array();
				while($postoji=$vec_postoje->fetch_assoc()){
					array_push($galerija, $postoji['naziv_foldera']);
				}
				if(!in_array($folder, $galerija)){
					if(mkdir('../../../gallery/'.$folder)){
						if($kon->query("INSERT INTO galerija (naziv_foldera,vest,autor) VALUES('$folder',$vest,'$autor')")){
						echo $kon->insert_id;
						}else echo $kon->error;

					}else echo "Nije napravljen folder,pokušajte opet";//header('Location:../galerija.php?ann=ngallery');

				}else echo "Folder sa tim imenom već postoji";
		}else echo $_GET['naslov'];//header('Location:../../../index.php');
}else header('Location:../../../index.php');


?>