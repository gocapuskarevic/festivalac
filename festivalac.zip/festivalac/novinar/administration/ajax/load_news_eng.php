<?php
require('../../../klase/PDO.php');



$post="SELECT vest_eng.sifra,vest_eng.naslov,vest_eng.vreme,vest_eng.klik,vest_eng.status,novinar.ime,kategorija.naziv AS kat FROM vest_eng INNER JOIN kategorija ON kategorija.sifra=vest_eng.kategorija INNER JOIN novinar ON novinar.sifra=vest_eng.autor ORDER BY vest_eng.sifra DESC"; 

$posti=$kon->query($post);

	
		$niz=array();
		while($postovi=$posti->fetch_assoc()){
			$niz[]=$postovi;
		}

echo json_encode($niz);






?>