<?php
session_start();
if(!isset($_SESSION['sign']))
    echo "<script>window.location.assign('../index.php');</script>";
else{
    require('../../klase/PDO.php');
    $privilegije=$kon->query("SELECT sifra,master FROM novinar WHERE mail='".$_SESSION['sign']."'");
    $privilegije=$privilegije->fetch_assoc();
    if($privilegije['sifra']==$privilegije['master'])
        $priv=1;
    else $priv=0;
}
if(isset($_GET['ann'])){
    $notice=$_GET['ann'];
    switch($notice){
        case 'error':
        echo "<script>alert('Nepoznati problem!')</script>";
        break;
        case 'empty':
        echo "<script>alert('Neko polje je prazno!')</script>";
        break;
        case 'true':
        echo "<script>alert('Uspesno sačuvani podaci!')</script>";
        break;
        case 'comm_true':
        echo "<script>alert('Uspesno odobren komentar!')</script>";
        break;
        case 'comm_false':
        echo "<script>alert('Komentar nije odobren,greška!')</script>";
        break;
        case 'true0':
        echo "<script>alert('Uspešno sačuvana vest!')</script>";
    }
}
?>
<html lang="en">
 
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <link rel="stylesheet" href="assets/vendor/charts/chartist-bundle/chartist.css">
    <link rel="stylesheet" href="assets/vendor/charts/morris-bundle/morris.css">
    <link rel="stylesheet" href="assets/vendor/fonts/material-design-iconic-font/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendor/charts/c3charts/c3.css">
    <link rel="stylesheet" href="assets/vendor/fonts/flag-icon-css/flag-icon.min.css">
    <title>Admin-dodaj vest</title>
    <style>
        @import url('https://fonts.googleapis.com/css?family=Hind+Siliguri:400,500,600,700|Lato:400,400i,700,700i&subset=latin-ext');
    </style>
    <link rel="stylesheet" type="text/css" href="admin-style.css">
        <script type="text/javascript" src="ckeditor/ckeditor.js"></script>
</head>

<body>
    <div class="dashboard-main-wrapper">
        <div class="dashboard-header">
            <nav class="navbar navbar-expand-lg bg-white fixed-top">
                <a class="navbar-brand" href="../../index.php">Festivalac</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
               
            </nav>
        </div>
        <div class="nav-left-sidebar sidebar-dark">
            <div class="menu-list">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav flex-column">
                            <li class="nav-divider">
                                Meni
                            </li>
                           
                            <li class="nav-item ">
                                <a class="nav-link active" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-1" aria-controls="submenu-1"><i class="fab fa-fw fa-wpforms"></i>Vesti <span class="badge badge-success">6</span></a>
                                <div id="submenu-1" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="index_vesti.php">Sve vesti</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="index_eng.php">Sve vesti - engleski</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="#">Nova vest</a>
                                        </li>
                                        
                                    </ul>
                                </div>
                            </li>
                             <li class="nav-item">
                                
                                <?php echo ($priv)? '<a class="nav-link" href="comments_p.php">Komentari</a>' : ''; ?>
                            </li>
                             <li class="nav-item">
                                <a class="nav-link" href="galerija.php">Napravi galeriju</a>
                            </li>
                            <li class="nav-item">
                                 <?php echo ($priv)? '<a class="nav-link" href="pregledaj_galerije.php">Pregledaj galerije</a>' : ''; ?>
                                
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link" href="../../pristup/logout.php">Odjavi se</a>
                            </li>
                          
                            
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content ">
                    <div class="row">
                        <div class="col-sm-12 col-md-9">
                <div id="add">
                    <h1>Dodaj novu vest</h1>
                    <form action="../../pristup/add.php" method="post" enctype="multipart/form-data">
                        <div class="form-goup">
                            <label for="title">Naslov</label> --->Engleski <input type="checkbox" name="language">
                                <input type="text" name="title" class="form-control"><br>
                                <p>Odaberi kategoriju:</p>
                                <select class="form-control" name="category">
                                  <option value="1">Najava</option>
                                  <option value="2">Izveštaj</option>
                                  <option value="3">Intervju</option>
                                  <option value="4">Članak</option>
                                  <option value="5">U fokusu</option>
                                  <option value="6">Top Lista</option>
                                  <option value="7">Must-See</option>
                                  </select><br>
                                  Izdvajamo<input type="checkbox" name="izdvajamo" style="margin-right: 15px;">
                                  Glavna vest<input type="checkbox" name="naslovna" onclick="vidi();" style="margin-right: 15px;">
                                  <div id="datum"><span>Do dana:</span><input type="date" name="naslovna_datum"></div><br>
                                <label for="content">Sadržaj</label>
                                <textarea name="content" id="content">
                                    

                                </textarea>
                                <script>
                                    CKEDITOR.replace('content');
                                </script>
                        </div><br>
                 
                        <br>
                        <br>
                        <p>Izaberite naslovnu fotografiju: </p>
                        <input type="file" name="image" class="form-control" accept=".jpg,.jpeg,.gif,.png">
                        <br>
                        
                        <br><br>
                        <input type="hidden" name="tagovi" id="tagovi">

                        <input type="submit" class="btn btn-default btn-block" onclick="napravi();" name="submit" value="Sačuvaj"><br>

                   

                   </form>

                
                </div><!--ovaj div se pojavljuje za nove vesti-->
                    </div>
                    <div class="col-sm-12 col-md-3">
                        <p>Dodati tagovi</p>
                        <div id="vec_dodati"></div>



                        <div id="tagovi">
                            <p>Dodaj novi tag</p>
                            <input type="text" maxlength="30" id="novi_tag"><br>
                            <button type="button" class="btn btn-primary" onclick="dodaj_novi_tag();">Dodaj tag</button><br><br>
                            <div class="dropdown">
                              <button onclick="myFunction()" class="btn btn-primary">Otvori listu</button>
                              <div id="myDropdown" class="dropdown-content">
                                <input type="text" placeholder="Search.." id="myInput" onkeyup="filterFunction()">
                                
                                 <?php
                                require('../../klase/trazi_tagove.php');
                                while($tag=$tagovi->fetch_assoc()){
                                    echo '<a href="#'.$tag['imetaga'].'" name="'.$tag['sifra'].'" onclick="stavi(this)" title="'.$tag['imetaga'].'">'.$tag['imetaga'].'</a>';
                                }
                                 ?>
                              </div>
                            </div>
                            <button type="button" class="btn btn-primary" onclick="dodajtag();">Stavi na listu</button><br><br>
                            
                           
                        </div>
                          <form action="" method="post" id="slika" enctype="multipart/form-data">
                            <input type="file" name="foto" name="foto_report">
                            <input type="hidden" name="" id="jezik">
                            <input type="button" name="foto_r" onclick="dodaj_sliku();" value="Dodaj sliku - foto reportaža">
                        </form>
                        <p id="link"></p>
                        
               
                        
                        

                    </div>
                     
                </div>
            </div>
            <div class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                            
                             Copyright © 2018 Concept. All rights reserved. Dashboard by <a href="https://colorlib.com/wp/">Colorlib</a>.
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
  
    <!-- Optional JavaScript -->
    <!-- jquery 3.3.1 -->
     
    <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <!-- bootstap bundle js -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <!-- slimscroll js -->
    <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <!-- main js -->
    <script src="assets/libs/js/main-js.js"></script>
    <!-- chart chartist js -->
    <script src="assets/vendor/charts/chartist-bundle/chartist.min.js"></script>
    <!-- sparkline js -->
    <script src="assets/vendor/charts/sparkline/jquery.sparkline.js"></script>
    <!-- morris js -->
    <script src="assets/vendor/charts/morris-bundle/raphael.min.js"></script>
    <script src="assets/vendor/charts/morris-bundle/morris.js"></script>
    <!-- chart c3 js -->
    <script src="assets/vendor/charts/c3charts/c3.min.js"></script>
    <script src="assets/vendor/charts/c3charts/d3-5.4.0.min.js"></script>
    <script src="assets/vendor/charts/c3charts/C3chartjs.js"></script>
    <script>
        function vidi(){
            document.getElementById('datum').style.display="inline";
        }


        var cuvanje_tagova=[];
        function myFunction() {
            document.getElementById("myDropdown").classList.toggle("show");
        }

function filterFunction() {
  var input, filter, ul, li, a, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  div = document.getElementById("myDropdown");
  a = div.getElementsByTagName("a");
  for (i = 0; i < a.length; i++) {
    txtValue = a[i].textContent || a[i].innerText;
    if (txtValue.toUpperCase().indexOf(filter) > -1) {
      a[i].style.display = "";
    } else {
      a[i].style.display = "none";
    }
  }
}

function pokazi(vr){
        document.getElementById('vec_dodati').innerHTML+="<p>"+vr+" <i class='fas fa-trash'  value='"+vr+"'  style='cursor:pointer;' onclick='obrisi_tag(this)'></i></p>";
}

    function stavi(vr){
        document.getElementById('myInput').value=vr.getAttribute("href").substr(1);//uzima sta je kliknuto
        document.getElementById('myInput').name=vr.getAttribute("name"); 
        
        
        vr.style.display="none";                       
        document.getElementsByClassName('show').style.backgroundColor="#fff";
        document.getElementsByClassName('dropdown-content')[0].style.height="0px";
        
    }

    function dodajtag(){//kad se klikne dodaj stavlja ga 
        var parametar=document.getElementById('myInput').value;
        var sifra=document.getElementById('myInput').name;
        pokazi(parametar);//u obavestenje
        
       cuvanje_tagova.push(sifra);//dodaje u zajednicku prom

    }

    function dodaj_novi_tag(){

        var novi=document.getElementById('novi_tag').value;
        cuvanje_tagova.push(novi);
        pokazi(novi);
        document.getElementById('novi_tag').value="";
    }

    function napravi(){
        //ovde daje value za input koji se salje na server
        var jebise=document.getElementById('tagovi');
        jebise.value=cuvanje_tagova.join();
        
    }
//nest,tamo,dodali,
  function obrisi_tag(koji){
        var index;
        var ko=koji.getAttribute('value');
       for(var i=0;i<cuvanje_tagova.length;i++){
        if(cuvanje_tagova[i]==ko){
            index=i;
        }
       }
       cuvanje_tagova.splice(index,1,"");
       
       //var sad_izbaci=document.getElementById('vec_dodati').querySelectorAll('p');
       document.getElementById('vec_dodati').innerHTML="";
      
               for(var d=0;d<cuvanje_tagova.length;d++){
                    if(cuvanje_tagova[d]!=""){
                        pokazi(cuvanje_tagova[d]);
                    }
                }
      
       
        }

        document.getElementById('novi_tag').addEventListener("keydown", function (e) {
            if(e.keyCode === 13)
            dodaj_novi_tag();
        });

CKEDITOR.config.height = 600;
function dodaj_sliku(){
    if(document.getElementsByName('foto')[0].value!=''){
              var lang;
        if(document.getElementsByName('language')[0].checked)
            lang=1;
        else lang=0;
        //alert(document.getElementById('jezik').name=lang);
        var ajax=new XMLHttpRequest();
        ajax.open("POST", "../../pristup/foto.php?jezik="+lang);
        var form = document.querySelector("#slika");
        var fm = new FormData(form);
        ajax.send(fm);
            ajax.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    //console.log(this.responseText);
                   // alert(this.responseText);
                   document.getElementById("link").innerHTML=this.responseText;
            }
        }
    }else alert('Prvo izaberite sliku');
  
    }

    </script>

</body>
 
</html>