function po_kategoriji(kat){
    var ajax1 = new XMLHttpRequest();
    var staje='OBJAVLJENE';
    var kategorija=false;
    switch(kat){
        case '1':{
        staje="OBJAVLJENE";
        kategorija=true;
        }
        
       
        break;
        case '2':
        staje="DRAFT";
        break;
        case '3':
        staje="OBRISANE";
        break;
        case '4':
        staje="RASPOREĐENO";
        break;
        case '5':
        staje="DRAFT"
        break;
        case '0':
        staje="NA ČEKANJU";
        break;
    }
    document.getElementById('odabrano').innerHTML=staje;
    

    ajax1.open("GET", "ajax/load_news_cat_eng.php?parametar="+kat, true);

    ajax1.send();
        ajax1.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                //console.log(this.responseText);
                var data1=JSON.parse(this.responseText);
                var prikaz1="<table class='table table-responsive-sm'>";
                prikaz1+="<tr><th>Opcije</th><th>Naslov</th><th>Autor</th><th>Kategorija</th><th>Zadnja izmena</th><th>Viđeno</th></tr>";
                for(var a=0;a<data1.length;a++){
                    prikaz1+="<tr>";
                    prikaz1+='<td class="w-10 mali"><a href="'+ispis(data1[a].status)+data1[a].sifra+'">Pregledaj</a><br><a href="izmena.php?lang=eng&number='+data1[a].sifra+'">Izmeni</a></td>';

                    prikaz1+='<td class="w-40">'+data1[a].naslov+'</a></td>';
                    prikaz1+='<td class="w-20">'+data1[a].ime+'</td>';
                    prikaz1+='<td class="w-10">'+data1[a].naziv+'</td>';
                    prikaz1+='<td class="w-10">'+data1[a].vreme.substr(0,10)+'</td>';
                    prikaz1+='<td class="w-10">'+data1[a].klik+'</td>';
                    prikaz1+="</tr>";
                }
                prikaz1+="</table>";
                document.getElementById('sve_vesti').innerHTML=prikaz1;
            }
        }

}

function samo_moje(sifra){
    var ajax2 = new XMLHttpRequest();
    document.getElementById('odabrano').innerHTML="MOJE VESTI";
    var je=sifra;
    ajax2.open("GET", "ajax/load_my_news_eng.php?sifra=" + je, true);
    ajax2.send();
     ajax2.onreadystatechange = function() {
     if (this.readyState == 4 && this.status == 200) {
        
                var data2=JSON.parse(this.responseText);
                var prikaz2="<table class='table table-responsive-sm'>";
                prikaz2+="<tr><th>Opcije</th><th>Naslov</th><th>Kategorija</th><th>Zadnja izmena</th><th>Viđeno</th></tr>";
                for(var a=0;a<data2.length;a++){
                    prikaz2+="<tr>";
                    prikaz2+='<td class="w-10 mali"><a href="'+ispis(data2[a].status)+data2[a].sifra+'">Pregledaj</a><br><a href="izmena.php?lang=eng&number='+data2[a].sifra+'">Izmeni</a></td>';
                    prikaz2+='<td class="w-40">'+data2[a].naslov+'</a></td>';
                    prikaz2+='<td class="w-10">'+data2[a].naziv+'</td>';
                    prikaz2+='<td class="w-10">'+data2[a].vreme.substr(0,10)+'</td>';
                    prikaz2+='<td class="w-10">'+data2[a].klik+'</td>';
                    prikaz2+="</tr>";
                }
                prikaz2+="</table>";
                document.getElementById('sve_vesti').innerHTML=prikaz2;
            }
}

}

function ama_bas_sve(){
    var ajax3 = new XMLHttpRequest();
    document.getElementById('odabrano').innerHTML="SVE VESTI";
    ajax3.open("GET", "ajax/load_news_eng.php", true);
    ajax3.send();
     ajax3.onreadystatechange = function() {
     if (this.readyState == 4 && this.status == 200) {
        
                var data3=JSON.parse(this.responseText);
                var prikaz3="<table class='table table-responsive-sm'>";
                prikaz3+="<tr><th>Opcije</th><th>Naslov</th><th>Autor</th><th>Kategorija</th><th>Zadnja izmena</th><th>Viđeno</th></tr>";
                for(var a=0;a<data3.length;a++){
                    prikaz3+="<tr>";
                    prikaz3+='<td class="w-10 mali"><a href="'+ispis(data3[a].status)+data3[a].sifra+'">Pregledaj</a><br><a href="izmena.php?lang=eng&number='+data3[a].sifra+'">Izmeni</a></td>';

                    prikaz3+='<td class="w-40">'+data3[a].naslov+'</a></td>';
                    prikaz3+='<td class="w-20">'+data3[a].ime+'</td>';
                    prikaz3+='<td class="w-10">'+data3[a].kat+'</td>';
                    prikaz3+='<td class="w-10">'+data3[a].vreme.substr(0,10)+'</td>';
                    prikaz3+='<td class="w-10">'+data3[a].klik+'</td>';
                    prikaz3+="</tr>";
                }
                prikaz3+="</table>";
                document.getElementById('sve_vesti').innerHTML=prikaz3;
            }
}

}

function ispis(status){var pise;
    if(status==1)
        return "../../eng/categories/selected-news.php?number=";
    else return "pregled_mod_news_eng.php?see=";
}




window.addEventListener('load',po_kategoriji(1));