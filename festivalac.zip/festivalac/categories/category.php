<?php
session_start();
if(isset($_SESSION['sign'])){
    $prikaz='<li><a href="../novinar/administration/index_a.php">Admin</a></li>';
    $english='<a href="../eng/index.php">EN</a>';
}
else{
    $prikaz="";
    $english='';
} 
?>
<script>
			function salji(){
				var vr=document.getElementsByName('field')[0].value;
				window.location.href="search.php?trazise="+vr
			}
		</script>
<?php include('../include/header.html');?>
<body>

		<header>
		<div class="container-fluid">
			
			<div class="row">
				<div class="col-sm-12">
					

					<?php include('navigacija.php'); ?>
						
			
			</div>
			
		</div>

</div>
		
	</header><!-- zavrsava se header tu su linkovi ka mrežama i navigacija-->
		<div class="container-fluid">
		<div class="row">
			<div class="col-md-8 col-md-offset-2 col-sm-12 proba">
				<section>
					<?php
				include('../klase/only_cat.php');
				if($cat_result->num_rows>0){
					$first=$cat_result->fetch_assoc()['sifra'];
					$tmp=$kon->query('SELECT vest.slika,vest.naslov,novinar.ime FROM vest INNER JOIN novinar ON vest.autor=novinar.sifra WHERE vest.sifra='.$first.'');
					$glavna=$tmp->fetch_assoc();

					//ovo je bilo na ovoj strani pre
					$vest=new Ch_cat($glavna['slika'],$glavna['naslov'],$first);
					$vest->last_news();

	
				}else echo("Uskoro...");
					

					?>
	
				</section>

				<main>
					<section>
				<h2>Ostale vesti iz iste kategorije</h2>
				<?php while($rows=$cat_result->fetch_assoc()){
					if(($rows['sifra']!=$first)||($rows['sifra']!=false)){
						$ostale=new Ch_cat($rows['slika'],$rows['naslov'],$rows['sifra']);
					$ostale->all_news();
					}
					
				} ?>

				<article class="btm">
					
		
				</article>
			</section>

			</main>
			
			</div>

			
		</div>
	</div>
		<div class="smoot"><a href="#"><i class="fas fa-angle-up"></i></a></div>
	<script type="text/javascript">
	window.onscroll = function() {myFunction()};
function myFunction() {
  if (document.documentElement.clientHeight > 350) {
    document.getElementsByClassName("smoot")[0].style.display = "block";
  }else if(document.documentElement.clientHeight < 350)document.getElementsByClassName("smoot")[0].style.display = "none";
}
		
	</script>
<?php include('../include/footer.html');?>
</body>
</html>

