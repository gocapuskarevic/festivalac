<?php
session_start();
if(isset($_SESSION['sign'])){
    $prikaz='<li><a href="../novinar/administration/index_a.php">Admin</a></li>';
    $english='<a href="../eng/index.php">EN</a>';
}
else{
    $prikaz="";
    $english='';
} 
include('../include/header.html');?>
<script>
			function salji(){
				var vr=document.getElementsByName('field')[0].value;
				window.location.href="search.php?trazise="+vr
			}
		</script>
<body>

	<header>
		<div class="container-fluid">
			
			<div class="row">
				<div class="col-sm-12">
					

					<?php include('navigacija.php'); ?>

						
			
			</div>
			
		</div>

</div>
		
	</header><!-- zavrsava se header tu su linkovi ka mrežama i navigacija-->
<div class="container-fluid">
		<div class="row">
			<div class="col-md-8 col-md-offset-2 col-sm-12 proba">
				<section>
					<h1>Rezultati pretrage</h1>
					<?php
					include("../klase/search.php");
					include("../klase/ch_cat.php");
					if($srch->num_rows>0){
						while($red=$srch->fetch_assoc()){
							$objekat=new Ch_cat($red['slika'],$red['naslov'],$red['sifra']);
							$objekat->all_news($red['tekst']);
						}
					}else echo '<p>Nema rezultata pretrage</p>';
					  ?>
				</section>
			</div>
		</div>
		
	</div>
		<div class="smoot"><a href="#"><i class="fas fa-angle-up"></i></a></div>
	<script type="text/javascript">
	window.onscroll = function() {myFunction()};
function myFunction() {
  if (document.documentElement.clientHeight > 350) {
    document.getElementsByClassName("smoot")[0].style.display = "block";
  }else if(document.documentElement.clientHeight < 350)document.getElementsByClassName("smoot")[0].style.display = "none";
}
		
	</script>
<?php include('../include/footer.html');?>
</body>
</html>