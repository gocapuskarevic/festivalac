<a href="../index.php" class="no-pad"><img src="../logo_mali.png"></a>
					<nav class="navbar navbar-inverse" style="margin-left: 40px;">
					

						<button class="navbar-toggle pull-left" data-toggle="collapse" data-target=".navHeaderCollapse">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>


						<div class="collapse navbar-collapse navHeaderCollapse">

							
						    <ul class="nav navbar-nav navbar-left">
						   
						      <li><a href="../index.php">VESTI</a></li>
						      <li><a href="category.php?category=2">IZVEŠTAJI</a></li>
						      <li id="taj"><a href="category.php?category=4">ČLANCI</a>
						      		<ul class="nav navbar-nav padajuci">
						      			<li><a href="category.php?category=5">U fokusu</a>
						      			<li><a href="category.php?category=6">Top liste</a>
						      			<li><a href="category.php?category=7">Must-See</a>
						      		</ul>
						      </li>
						      <li><a href="category.php?category=3">INTERVJUI</a></li>
						      <!--<li><a href="gallery.php">GALERIJA</a></li>-->
						      <?php echo $prikaz; ?>
						      <li style="margin-top: 3px;"><input type="text" name="field" class="form-control" style="display:inline;" placeholder="Pretraži vesti..." maxlength="30"></li>
						      <li><a href="#" onclick="salji();"><i class="fa fa-search"></i></a></li>
						    </ul>
				</div><!--ovaj div drzi sve za hamburger meni posle-->
	

						   <div class="top-right">
						    	<a href=""><i class="fab fa-instagram" title="Instagram"></i></a>
						    	<a href=""><i class="fa fa-twitter-square" title="Twiter"></i></a>
						    	<a href="https://www.facebook.com/nemanja.neskovic.73"><i class="fa fa-facebook-square" title="Facebook"></i></a>
						    	<?php echo $english; ?>
						    </div>

						    
						</nav>