<?php
session_start();
if(isset($_SESSION['sign'])){
    $prikaz='<li><a href="../novinar/administration/index_a.php">Admin</a></li>';
    $english='<a href="../eng/index.php">EN</a>';
}
else{
    $prikaz="";
    $english='';
} 
include('../include/header.html');


?>
</head>
<body>
	<div class="container-fluid">
		<div class="row">
			<header>
				<div class="col-sm-12">
					<?php include('navigacija.php'); ?>
						</header>
		</div>

		<div class="col-sm-12 col-md-6 col-md-offset-3" style="text-align: justify;">
			<h1 style="text-align: center;">FESTIVALAC – O NAMA</h1>
			<p>Festivalac.com je zamišljen kao web portal koji će pratiti sva događanja i aktivnosti u vezi sa festivalskim temama, kako na području Srbije, tako i širom regiona i Evrope. </p>
			
			<p>Na stranicama ovog portala čitaoci će moći da se upoznaju sa najrazličitijim festivalskim manifestacijama kroz vesti, intervjue, najave, kolumne, izveštaje, fotografije.</p>
			<p>Naša ideja jeste da Festivalac bude svojevrstan vodič kroz festivalsku kulturu, početna stanica prilikom planiranja posete nekom događaju ovakvog tipa. Sadržaj vebsajta nudi uvid u aktuelnu festivalsku scenu na svim meridijanima, promociju događaja vrednih pažnje i originalne priče motivisane festivalskim avanturama. </p>
		
			
		</div>
	</div>



<?php
include('../include/footer.html');
?>