<?php
session_start();
if(isset($_SESSION['sign'])){
    $prikaz='<li><a href="../novinar/administration/index_a.php">Admin</a></li>';
    $english='<a href="../eng/index.php">EN</a>';
}
else{
    $prikaz="";
    $english='';
} 
include('../include/header.html');
if(isset($_GET['message'])) echo "<script>alert('Poruka je poslata,očekujte brz odgovor!');</script>";

?>
</head>
<body>
	<div class="container-fluid">
		<div class="row">
			<header>
				<div class="col-sm-12">
					<?php include('navigacija.php'); ?>
						</header>
		</div>

		<div class="col-sm-12 col-md-6 col-md-offset-3" style="text-align: justify;">
			<h1 style="text-align: center;">Kontakt</h1>
			<p>Ukoliko imate pitanja u vezi sa festivalima (datumima održavanja, promenama satnice, cenama ulaznica, smeštajem u kampu i svemu ostalom), želite da promovišete vaš festival ili biste da postanete deo naše redakcije, na pravom ste mestu.</p>
<p>Vaše upite možete slati putem ovog formulara, a mi ćemo se truditi da vam odgovorimo u najkraćem mogućem roku.</p>
			<div class="form-group">
				<form method="post" action="../klase/poruka.php">
					<label for="ime">Vaše ime</label>
					<input type="text" name="ime" id="ime" class="form-control" maxlength="60" placeholder="Polje je obavezno" required>
					<label for="email">Vaš email</label>
					<input type="email" name="email" id="email" class="form-control" maxlength="60" placeholder="Polje je obavezno" required>
					<label for="poruka">Poruka</label>
					<textarea class="form-control" id="poruka" name="poruka" placeholder="Vaša poruka..."></textarea><br><br>
					
					<input type="submit" class="form-control" name="por" value="Pošalji poruku">

				</form>
			</div>
			
		</div>
	</div>
</body>


<?php
include('../include/footer.html');
?>