<?php
include('../include/header.html');
?>
</head>
<body>
	<div class="container-fluid">
		<div class="row">
			<header>
				<div class="col-sm-12">
					 <a href="../index.php" class="no-pad"><img src="../../logo_mali.png"></a>
					<nav class="navbar navbar-inverse" style="margin-left: 40px;">

						<button class="navbar-toggle pull-left" data-toggle="collapse" data-target=".navHeaderCollapse">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>

						<div class="collapse navbar-collapse navHeaderCollapse">
						  
						    <ul class="nav navbar-nav navbar-left">

						         <li><a href="../index.php">NEWS</a></li>
						      <li><a href="category.php?category=2">REPORTS</a></li>
						      <li id="taj"><a href="category.php?category=4">ARTICLES</a>
						      		<ul class="nav navbar-nav padajuci">
						      			<li><a href="category.php?category=5">In focus</a>
						      			<li><a href="category.php?category=6">Top lists</a>
						      			<li><a href="category.php?category=7">Must-See</a>
						      		</ul>
						      </li>
						      <li><a href="category.php?category=3">INTERVIEW</a></li>
						      <li><a href="gallery.php">GALLERY</a></li>
						      <li style="margin-top: 3px;"><input type="text" name="field" class="form-control" style="display:inline;" placeholder="Search..." maxlength="30"></li>
						      <li><a href="#" onclick="salji();"><i class="fa fa-search"></i></a></li>
						    </ul>
				</div><!--ovaj div drzi sve za hamburger meni posle-->
	

						   <div class="top-right">
						    	<a href=""><i class="fab fa-instagram" title="Instagram"></i></a>
						    	<a href=""><i class="fa fa-twitter-square" title="Twiter"></i></a>
						    	<a href="https://www.facebook.com/nemanja.neskovic.73"><i class="fa fa-facebook-square" title="Facebook"></i></a>
						    	<a href="../../index.php"><img src="../srbija.png" style="width:35px;height: 30px;"></a>
						    </div>
						</nav>
						</header>
		</div>

		<div class="col-sm-12 col-md-6 col-md-offset-3" style="text-align: justify;">
			<h1 style="text-align: center;">IMPRESSUM</h1>
				<p>Sadržaj portala je proizvod rada redakcije i saradnika portala Festivalac.</p>

				<p>Sav materijal na ovom portalu zaštićen je autorskim pravima i svaka neovlašćena upotreba može predstavljati kršenje Zakona o autorskom i srodnim pravima, Zakona o žigovima ili drugih zakona iz oblasti intelektualne svojine. Osim ukoliko je drugačije naznačeno na drugom mestu na ovom portalu, sav sadržaj možete pregledati, kopirati, štampati ili preuzimati isključivo za ličnu, nekomercijalnu upotrebu i u informativne svrhe, pod uslovom da sve naznake o autorskim pravima ili drugim vlasničkim informacijama koji su sadržani u originalnom dokumentu zadržite u svim kopijama.</p>

				<p>Sadržaj za dalju on-line distribuciju ili korišćenje u drugim medijima može se koristiti isključivo uz saglasnost uredništva portala.</p>

				<p>Ako mislite da bilo koja informacija na portalu nije tačna, molimo vas da nas blagovremeno o tome obavestite, kako bi se sprovele adekvatne mere za proveru ispravnosti informacija.</p>

				<p>Podatke iz procesa registracije, te ostale podatke o korisniku, portal Festivalac.com neće davati na uvid trećoj strani, osim u slučaju kada je takva obaveza regulisana Zakonom.</p>

				<p>Linkovi sadržani na portalu, koji vode na nezavisne sajtove, prikazani su isključivo pogodnosti čitalaca i obaveštavanja. Festivalac.com nije pregledao sadržaj ovih sajtova, ne kontroliše ih i nije odgovoran za bilo koji od ovih sajtova ili njihove sadržaje. Stoga, Festivalac.com nije njihov predstavnik, ne pruža nikakve garancije i ne prihvata obaveze u vezi sa ovim sajtovima ili bilo kojim informacijama, softverom ili drugim proizvodima koji se tamo mogu naći, ili sa rezultatima koji su posledica njihove upotrebe.</p>

		</div>
	</div>
</body>


<?php
include('../include/footer.html');
?>