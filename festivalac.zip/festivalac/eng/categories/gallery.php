<?php
session_start();
if(isset($_SESSION['sign']))
	$prikaz='<li><a href="../../novinar/administration/index_a.php">Admin</a></li>';
else $prikaz="";
include('../include/header.html');
?>

<style>
	input[type=text]:focus,input[type=password]:focus,input[type=email]:focus,input[type=submit]:focus{
	box-shadow: 0 0 5px #9d9d9d;
	border: 1px solid #9d9d9d;
	}
#user_comm:focus{

	box-shadow: 0 0 5px #9d9d9d;
	border: 1px solid #9d9d9d;
	outline: none;
}</style>
<link rel="stylesheet" href="lightbox/src/hes-gallery.css">
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/sr_RS/sdk.js#xfbml=1&version=v3.3"></script>


<script>
			function salji(){
				var vr=document.getElementsByName('field')[0].value;
				window.location.href="search.php?trazise="+vr
			}
			
		</script>
</head>
<body>

		<div class="container-fluid">
			
			<div class="row">
				<header>
				<div class="col-sm-12">
					 <a href="../index.php" class="no-pad"><img src="../../logo_mali.png"></a>
					<nav class="navbar navbar-inverse" style="margin-left: 40px;">

						<button class="navbar-toggle pull-left" data-toggle="collapse" data-target=".navHeaderCollapse">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>

						<div class="collapse navbar-collapse navHeaderCollapse">
						  
						     <ul class="nav navbar-nav navbar-left">
						   
						       <li><a href="../index.php">NEWS</a></li>
						      <li><a href="category.php?category=2">REPORTS</a></li>
						      <li id="taj"><a href="category.php?category=4">ARTICLES</a>
						      		<ul class="nav navbar-nav padajuci">
						      			<li><a href="category.php?category=5">In focus</a>
						      			<li><a href="category.php?category=6">Top lists</a>
						      			<li><a href="category.php?category=7">Must-See</a>
						      		</ul>
						      </li>
						      <li><a href="category.php?category=3">INTERVIEW</a></li>
						      <li><a href="gallery.php">GALLERY</a></li>
						      <?php echo $prikaz; ?>
						      <li style="margin-top: 3px;"><input type="text" name="field" class="form-control" style="display:inline;" placeholder="Search..." maxlength="30" id="myInput"></li>
						      <li><a href="#" onclick="salji();" id="btn"><i class="fa fa-search"></i></a></li>
						    </ul>
						    </div><!--ovaj div drzi sve za hamburger meni posle-->

						    <div class="top-right">
						    	<a href=""><i class="fab fa-instagram" title="Instagram"></i></a>
						    	<a href=""><i class="fa fa-twitter-square" title="Twiter"></i></a>
						    	<a href="https://www.facebook.com/nemanja.neskovic.73"><i class="fa fa-facebook-square" title="Facebook"></i></a>
						    	<a href="../../index.php"><img src="../srbija.png" style="width:35px;height: 30px;"></a>
						    </div>
						</nav>
						</div>
					</header>
			
			</div>
			<div class="row">
			<div class="col-md-10 col-md-offset-1 col-sm-12 centar">
				<div id="rezultat">
				<div class="col-sm-12">
					<main style="overflow: hidden;">
							<div class="hes-gallery" data-wrap="true" data-img-count="3" style="overflow: hidden;">

							
							<?php
							require('../klase/search_images_gallery.php');
							if($sve->num_rows>0){
								$brojac=0;
							while($gall=$sve->fetch_assoc()){
								$sl=$gall['sifra_g'];
								$pr=str_replace('-', '/',$gall['naziv_foldera']);
								$pr1=str_replace('_','.',$pr);
								$slika=$kon->query("SELECT naziv_slike,odakle FROM slike_galerija WHERE folder=$sl LIMIT 1");
								$slika=$slika->fetch_assoc();
								if($slika['odakle']==0) $prikaz='<div class="uzana">'.$slika['naziv_slike'].'</div>';
								else
									$prikaz='<div><a href="selected_gallery.php?num='.$gall['sifra_g'].'"><img src="../../gallery/'.$gall['naziv_foldera'].'/'.$slika['naziv_slike'].'"></a></div>';
									
								if($brojac<2)
									echo '<div class="dve_galerije">'.$prikaz.'<h3><a href="selected_gallery.php?num='.$gall['sifra_g'].'">'.$pr1.'</a></h3></div>';
								else echo '<div class="sve_galerije">'.$prikaz.'<h3 ><a href="selected_gallery.php?num='.$gall['sifra_g'].'">'.$pr1.'</a></h3></div>';
								$brojac++;
							}
							

						}else echo("Soon");
					
						 ?>
						</div>
	
						</main>
					</div>
					</div><!--ovo je div koji sadrzi odabranu galeriju-->
					
			
			</div><!--ovo je div koji sadrzi sve-->
			
			</div><!--ovo je div koji je row-->
		</div>
			<div class="smoot"><a href="#"><i class="fas fa-angle-up"></i></a></div>
	<script type="text/javascript">
	window.onscroll = function() {myFunction()};
function myFunction() {
  if (document.documentElement.clientHeight > 350) {
    document.getElementsByClassName("smoot")[0].style.display = "block";
  }else if(document.documentElement.clientHeight < 350)document.getElementsByClassName("smoot")[0].style.display = "none";
}
		


	</script>
	
<?php include('../include/footer.html');?>
	
