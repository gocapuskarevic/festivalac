<?php
session_start();
if(isset($_SESSION['sign'])){
	$prikaz='<li><a href="../../novinar/administration/index_a.php">Admin</a></li>';
	require('../klase/PDO.php');
    $privilegije=$kon->query("SELECT sifra,master FROM novinar WHERE mail='".$_SESSION['sign']."'");
    $privilegije=$privilegije->fetch_assoc();
    if($privilegije['sifra']==$privilegije['master'])
        $priv=1;
    else $priv=0;


}else{
	 $prikaz="";
	 $priv=0;
}


include('../include/header.html');?>
<style>
	input[type=text]:focus,input[type=password]:focus,input[type=email]:focus,input[type=submit]:focus{
	box-shadow: 0 0 5px #9d9d9d;
	border: 1px solid #9d9d9d;
	}
#user_comm:focus{

	box-shadow: 0 0 5px #9d9d9d;
	border: 1px solid #9d9d9d;
	outline: none;
}
.tagovi{
	padding: 5px;
	background-color: #f7f8f9;
	color:#000;
	transition:0.3s all ease;
	margin-right: 3px;
	display: inline-block;
}

.tagovi:visited{
	background-color: #f7f8f9;
	}

.tagovi:hover{
	background-color: #dcdfe5;
}
</style>
<script>
			function salji(){
				var vr=document.getElementsByName('field')[0].value;
				window.location.href="search.php?trazise="+vr
			}
		</script>
</head>
<body>
	<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/sr_RS/sdk.js#xfbml=1&version=v3.3"></script>
	<?php if(isset($_GET['number'])) require('../klase/res_for_selected.php');
		else header('Location:../index.php');
	if(isset($_GET['ann'])){
		switch($_GET['ann']){
			case 'no':
			echo "<script>alert('Došlo je do greške,pokušajte ponovo da pošaljete komentar')</script>";
			break;
			case 'yes':
			echo "<script>alert('Uspešno ste poslali komentar! Hvala!')</script>";
			break;
		}
	}
	if($res->num_rows==1)
		$vest=$res->fetch_assoc();
	else
		die("<h2>Soon</h2>");
	 ?>

		<div class="container-fluid">
			
			<div class="row">
				<header>
				<div class="col-sm-12">
					 <a href="../index.php" class="no-pad"><img src="../../logo_mali.png"></a>
					<nav class="navbar navbar-inverse" style="margin-left: 40px;">

						<button class="navbar-toggle pull-left" data-toggle="collapse" data-target=".navHeaderCollapse">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>

						<div class="collapse navbar-collapse navHeaderCollapse">
						   <ul class="nav navbar-nav navbar-left">
						   
						       <li><a href="../index.php">NEWS</a></li>
						      <li><a href="category.php?category=2">REPORTS</a></li>
						      <li id="taj"><a href="category.php?category=4">ARTICLES</a>
						      		<ul class="nav navbar-nav padajuci">
						      			<li><a href="category.php?category=5">In focus</a>
						      			<li><a href="category.php?category=6">Top lists</a>
						      			<li><a href="category.php?category=7">Must-See</a>
						      		</ul>
						      </li>
						      <li><a href="category.php?category=3">INTERVIEW</a></li>
						      <li><a href="gallery.php">GALLERY</a></li>
						      <?php echo $prikaz; ?>
						      <?php echo ($priv)? '<li><a href="../../novinar/administration/izmena.php?lang=eng&number='.$vest['sifra'].'">Uredi vest</a></li>' : ''; ?>
						      <li style="margin-top:8px;">
						   			<input type="text" name="field" class="form-control" style="display:inline;" placeholder="Search..." maxlength="30"></li>
						      <li><a href="#" onclick="salji();"><i class="fa fa-search"></i></a></li>
						      
						    </ul>
						    </div><!--ovaj div drzi sve za hamburger meni posle-->

						    <div class="top-right">
						    	<a href=""><i class="fab fa-instagram" title="Instagram"></i></a>
						    	<a href=""><i class="fa fa-twitter-square" title="Twiter"></i></a>
						    	<a href="https://www.facebook.com/nemanja.neskovic.73"><i class="fa fa-facebook-square" title="Facebook"></i></a>
						    	<a href="../../index.php"><img src="../srbija.png" style="width:35px;height: 30px;"></a>
						    </div>
						</nav>
						</header>
			
		
			<div class="col-md-10 col-md-offset-1 col-sm-12 ">
				<div class="col-sm-12 col-md-8">
					<main><?php
					
						$vest_je= new Selected($vest['naslov'],$vest['ime'],$vest['vreme'],$vest['slika'],$vest['tekst']);
						$vest_je->show($vest['kategorija']);
						if($tagovi->num_rows>0){
							echo '<p>Tags</p>';
							while($jedan_po_jedan=$tagovi->fetch_assoc())
							$vest_je->tags($jedan_po_jedan['sifra'],$jedan_po_jedan['imetaga']);

						}else echo "";
					
						 ?>

						 <div id="btn_gallery">
						 	<?php include('../klase/search_gallery.php'); ?>
						 		
						 	</div>
					

				<div class="fb-like" data-href="https://festivalac.com" data-width="" data-layout="button_count" data-action="like" data-size="small" data-show-faces="false" data-share="true"></div>
				<article>
					<h2>Leave comment</h2>
					<form action="../klase/new_comm.php" method="post" class="form-group">
						<label for="user_name">Name:</label>
							<input type="text" name="user_name" id="user_name" class="form-control" maxlength="50" required>
							<label for="user_comm">Comment:</label>
							<textarea class="form-control" name="user_comm" id="user_comm" maxlength="950" required></textarea><br>
							<input type="hidden" name="hdn" value="<?php echo $_GET['number'] ?>">
							<input type="submit" name="send_comm" value="Pošalji komentar" class="form-control">
					</form>
				</article>
				<article id="comments">
						<h2>Comments</h2>
						<?php include('../klase/news_comm_aded.php');
						
						if($svi_komentari->num_rows>0){
							while($jedan=$svi_komentari->fetch_assoc()){
								echo "<section>
							<p><b>".$jedan['ime'].": </b>".$jedan['sadrzaj']."</p>
							<p><i>Datum: ".$jedan['datum']."</i></p>
						</section>";
							}
						}else echo "<div class='col-sm-12'><h3 stye='font-size:50px;'>No comments yet...</h3></div>"; ?>
						


					</article> <!--div sa komentarima čitalaca-->





			</main>

			</div><!--ovo je div koji sadrzi odabranu vest-->
			<div class="col-sm-12 col-md-4">
				<aside style="margin-left: 15px;">
					<section>
						<h2>The most popular</h2>
						
							<?php
							require('../klase/selected_sa_strane.php');
							if($ostalo->num_rows>0){
								while($ajmo=$ostalo->fetch_assoc())
									if($ajmo['sifra']!=$vest['sifra'])
									echo '<article class="sa_strane"><img src="../images/'.$ajmo['slika'].'" alt="" class="float-left">
									<h3 class="no-top-margin"><a href="selected-news.php?number='.$ajmo['sifra'].'">'.$ajmo['naslov'].'</a></h3></article>';
									else echo "";
							}else echo "";
							 ?>
							
							
						

					</section>
				</aside>
				

			</div><!--ovo je div koji sadrzi aside,najčitanije-->
			</div><!--ovo je div koji sadrzi wrapp odabranu vest i aside-->
			
			
		</div>
	</div>
	<div class="smoot"><a href="#"><i class="fas fa-angle-up"></i></a></div>
	<script type="text/javascript">
	window.onscroll = function() {myFunction()};
function myFunction() {
  if (document.documentElement.clientHeight > 350) {
    document.getElementsByClassName("smoot")[0].style.display = "block";
  }else if(document.documentElement.clientHeight < 350)document.getElementsByClassName("smoot")[0].style.display = "none";
}
		
	</script>
<?php include('../include/footer.html'); ?>

</body>
</html>