<?php
require_once('PDO.php');
require_once('display.php');

function selektuj($start,$limit){
	global $kon;
	$all=$kon->query("SELECT vest_eng.sifra,vest_eng.naslov,vest_eng.autor,vest_eng.kategorija,vest_eng.status,vest_eng.vreme,vest_eng.klik,vest_eng.slika,status_vesti.naziv,kategorija.naziv FROM kategorija INNER JOIN vest_eng ON vest_eng.kategorija=kategorija.sifra INNER JOIN status_vesti ON vest_eng.status=status_vesti.sifra WHERE vest_eng.status=1 AND vest_eng.kategorija=1 ORDER BY vest_eng.vreme_objave DESC LIMIT $start,$limit");
	
	$array=array();
	while($row=$all->fetch_assoc())
		$array[]=$row;
	return $array;
	
}

if(isset($_GET['start'])){
	$start=$_GET['start'];
	$limit=$_GET['limit'];
	$evo=selektuj($start,$limit);
	echo json_encode($evo);
}

?>