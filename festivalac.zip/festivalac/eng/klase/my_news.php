<?php
session_start();
require('PDO.php');
$novinari=$kon->query("SELECT novinar.mail from novinar");
//var_dump($novinari);
$niz_n=array();
while($tmp=$novinari->fetch_array())
	array_push($niz_n,$tmp['mail']);
//print_r($niz_n);
if(isset($_SESSION['sign'])&&in_array($_SESSION['sign'],$niz_n)){
	$res=$kon->query("SELECT vest.sifra,vest.naslov,vest.tekst,vest.kategorija,vest.status,vest.slika FROM vest INNER JOIN novinar ON novinar.sifra=vest.autor WHERE novinar.mail='".$_SESSION['sign']."'");
	if($res->num_rows>0){
		header('Location:../novinar/administration/pages/my_news.php');
		
	}else header('Location:../novinar/administration/pages/my_news.php?news=empty');
	var_dump($res);
}else header('Location:../index.php');
?>