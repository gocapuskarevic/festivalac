<?php
require('PDO.php');
$tagovi=$kon->query("SELECT * FROM tagovi ORDER BY imetaga ASC");

?>