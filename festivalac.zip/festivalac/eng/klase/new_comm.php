<?php
include_once('PDO.php');
$sifra=$_POST['hdn'];
if(isset($_POST['send_comm'])){
	if((!empty($_POST['user_name'])&&is_string($_POST['user_name']))&&(!empty($_POST['user_comm'])&&is_string($_POST['user_comm']))){
		$user=$kon->real_escape_string(trim(htmlspecialchars($_POST['user_name'])));
		$comment=$kon->real_escape_string(trim(htmlspecialchars($_POST['user_comm'])));
		$odob=0;


		if($result=$kon->prepare("INSERT INTO komentari(vest,ime,sadrzaj,odobri,datum) VALUES(?,?,?,?,?)")){
			$datum=date('Y-m-d',time());
			$result->bind_param('issis',$sifra,$user,$comment,$odob,$datum);
			if($result->execute()){
			header('Location:../categories/selected-news?number='.$sifra.'&ann=yes');
		}else
		echo $kon->errno." ".$kon->error;
			//header('Location:../categories/selected-news?number='.$sifra.'?ann=no');
		}


		
		}else header('Location:../categories/selected-news?number='.$sifra.'');

	}else header('Location:../categories/selected-news?number='.$sifra.'');
















?>