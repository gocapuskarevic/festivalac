<?php
require('PDO.php');
require('display.php');

require_once('PDO.php');
$res=$kon->query("SELECT * FROM glavna_eng ORDER BY datum DESC LIMIT 1");
while($r=$res->fetch_assoc()){
	$date=new DateTime($r['datum'],new DateTimeZone('Europe/Belgrade'));
		if($date->getTimestamp()>time()){
			$si=$r['vest_eng'];
			$main_news=$kon->query('SELECT * from vest_eng WHERE status=1 AND sifra='.$si.'');
			$main_news=$main_news->fetch_assoc();
		}else{
			$main_news=$kon->query('SELECT * from vest_eng WHERE status=1 ORDER BY vreme_objave DESC LIMIT 1');
			$main_news=$main_news->fetch_assoc();//ovaj deo je za glavnu vest,trazi id i pravi dalje instancu
		}
}




//ako nema izdvajamo



//sada selektuje najcitanije za deo sa strane
$sa_strane=$kon->query('SELECT vest_eng.sifra,vest_eng.naslov,vest_eng.tekst,vest_eng.vreme,vest_eng.slika from vest_eng INNER JOIN izdvajamo_eng ON vest_eng.sifra=izdvajamo_eng.vest WHERE vest_eng.status=1 ORDER BY vest_eng.sifra DESC LIMIT 3');

$clanak=$kon->query('SELECT * FROM vest_eng WHERE (kategorija=4 OR kategorija=5 OR kategorija=6 OR kategorija=7) AND status=1 ORDER BY vreme_objave DESC LIMIT 4');
$intervju=$kon->query('SELECT * FROM vest_eng WHERE kategorija=3 AND status=1 ORDER BY vreme DESC LIMIT 3');


$izvestaji=$kon->query('SELECT * FROM vest_eng WHERE kategorija=2 AND status=1 ORDER BY vreme DESC LIMIT 3');



















?>