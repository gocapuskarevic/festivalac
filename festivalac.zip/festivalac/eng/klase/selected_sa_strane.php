<?php
require('PDO.php');
$po_cemu=$_GET['number'];
$krit=$kon->query("SELECT kategorija From vest_eng WHERE sifra=$po_cemu");
$krit=$krit->fetch_assoc();
$prom=$krit['kategorija'];
$ostalo=$kon->query("SELECT vest_eng.sifra,vest_eng.naslov,vest_eng.slika FROM vest_eng WHERE kategorija=$prom AND status=1 ORDER BY vest.klik DESC LIMIT 6");





?>