<?php
require('PDO.php');
$izvestaji=$kon->query("SELECT vest.sifra,vest.naslov FROM vest WHERE kategorija=2 ORDER BY sifra DESC limit 15");



?>