<?php
if(isset($_POST['podaci'])){
	require('PDO.php');
	$ime=trim(htmlspecialchars($_POST['first_name']));
	$email=trim(htmlspecialchars($_POST['email']));
	if($kon->query("INSERT INTO newsletter (ime,mail) VALUES('$ime','$email')")){
		header('Location:../index.php?ann=newsletter');
	}

}else header('Location:../index.php');


?>