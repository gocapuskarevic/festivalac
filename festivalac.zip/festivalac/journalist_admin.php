<!DOCTYPE html>
<html>
<head>
	<title>Welcome</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	  <style>
	  	input[type=text]:focus,input[type=password]:focus,input[type=email]:focus,input[type=submit]:focus{
			  box-shadow: 0 0 5px #9d9d9d;
			  border: 1px solid #9d9d9d;
		}/*
		body{
			background-image: url(images/oko.png);
		}*/
	  </style>
	  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	<?php
	if(isset($_GET['error']))
		switch($_GET['error']){
			case 'je':
			echo "<script>alert('Pogrešni parametri');</script>";
			break;
			case 'wrpas':
			echo "<script>alert('Pogrešno ste ukucali lozinku,pokušajte ponovo!');</script>";
			break;
			case 'no':
			echo "<script>alert('Došlo je do greške ,pokušajte ponovo!');</script>";

		}
		
	?>
	<div class="container-fluid">
		<div class="jumbotron">
			<h1><cite>&bdquo;Otvori se Sisi, otvori se Sesile! To nije to! &rdquo;</cite></h1>
			<p class="text-right"><cite>Popey(1937)</cite></p>

		</div>
		<div class="container-fluid">
			<div class="form-group">
				
		<form method="post" action="pristup/login.php" class="form-group text-center">
			<label for="ime">Ime:
				<input type="email" class="form-control" name="ime" required></label><br>
				<label for="loz">Lozinka:
				<input type="password" class="form-control" name="loz" required></label>
				<br>

				<button type="submit" class="btn btn-default" value="on" name="podaci">Uloguj se</button>
			</form>


				<hr><hr>
			<br><br><!--FORMA ZA REGISTRACIJU NOVIH MODERATORA-->
		<form action="pristup/registre.php" method="post" class="form-group text-center">
		<p>Napravi novi nalog</p>
		<label for="ime_n">Ime:
		<input type="text" maxlength="30" name="ime_n" id="ime_n" class="form-control" required></label><br>
		<label for="mail_n">E-mail:
		<input type="email" maxlength="30" name="mail_n" id="mail_n" class="form-control" required></label><br>
		<label for="pass_n">Lozinka:
		<input type="password" maxlength="30" name="pass_n" id="pass_n" class="form-control" required></label><br>
		<label for="pass_a">Ponovi lozinku:
		<input type="password" maxlength="30" name="pass_a" id="pass_a" class="form-control" required></label><br>

		<button type="submit" class="btn btn-default" value="new" name="novi_p">Registruj se</button>
		</form>
			</div>
		</div>


	



	</div>



</body>
</html>