<?php
require_once('PDO.php');
require_once('display.php');

function selektuj($start,$limit){
	global $kon;
	$all=$kon->query("SELECT vest.sifra,vest.naslov,vest.autor,vest.kategorija,vest.status,vest.vreme,vest.klik,vest.slika,status_vesti.naziv,kategorija.naziv FROM kategorija INNER JOIN vest ON vest.kategorija=kategorija.sifra INNER JOIN status_vesti ON vest.status=status_vesti.sifra WHERE vest.status=1 AND vest.kategorija!=2 AND vest.kategorija!=8 ORDER BY vest.vreme_objave DESC LIMIT $start,$limit");
	
	$array=array();
	while($row=$all->fetch_assoc())
		$array[]=$row;
	return $array;
	
}

if(isset($_GET['start'])){
	$start=$_GET['start'];
	$limit=$_GET['limit'];
	$evo=selektuj($start,$limit);
	echo json_encode($evo);
}

?>