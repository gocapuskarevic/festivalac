<?php
require("PDO.php");
require("ch_cat.php");
$category=0;
if(isset($_GET['category'])){
	if($_GET['category']==1||$_GET['category']==2||$_GET['category']==3||$_GET['category']==5||$_GET['category']==6||$_GET['category']==7||$_GET['category']==8){
		$category=$_GET['category'];
		$cat_result=$kon->query("SELECT vest.sifra,vest.naslov,vest.tekst,vest.status,vest.vreme,vest.slika,kategorija.naziv AS kategorija,novinar.ime FROM vest INNER JOIN kategorija ON vest.kategorija=kategorija.sifra INNER JOIN novinar ON vest.autor=novinar.sifra WHERE vest.kategorija=$category AND vest.status=1 ORDER BY vest.vreme_objave DESC");
	}else if($_GET['category']==4){
	    $cat_result=$kon->query("SELECT vest.sifra,vest.naslov,vest.tekst,vest.status,vest.vreme,vest.slika,kategorija.naziv AS kategorija,novinar.ime FROM vest INNER JOIN kategorija ON vest.kategorija=kategorija.sifra INNER JOIN novinar ON vest.autor=novinar.sifra WHERE (vest.kategorija=4 OR vest.kategorija=5 OR vest.kategorija=6 OR vest.kategorija=7) AND vest.status=1 ORDER BY vest.vreme_objave DESC");
	}
}else $cat_result=$kon->query("SELECT vest.sifra,vest.naslov,vest.tekst,vest.status,vest.vreme,vest.slika,kategorija.naziv AS kategorija,novinar.ime FROM vest INNER JOIN kategorija ON vest.kategorija=kategorija.sifra INNER JOIN novinar ON vest.autor=novinar.sifra WHERE vest.kategorija=1 AND vest.status=1 ORDER BY vest.vreme_objave DESC");


	

?>
