<?php
require('PDO.php');
require('display.php');
/*
$all=$kon->query("SELECT vest.sifra,vest.naslov,vest.tekst,vest.autor,vest.kategorija,vest.status,vest.vreme,vest.klik,vest.slika,status_vesti.naziv,kategorija.naziv FROM kategorija INNER JOIN vest ON vest.kategorija=kategorija.sifra INNER JOIN status_vesti ON vest.status=status_vesti.sifra WHERE vest.status=1 ORDER BY vest.sifra DESC LIMIT 6");*///sve vesti koje postoje
require_once('PDO.php');
$res=$kon->query("SELECT * FROM glavna LIMIT 1");
while($r=$res->fetch_assoc()){
	$date=new DateTime($r['datum'],new DateTimeZone('Europe/Belgrade'));
		if($date->getTimestamp()>time()){
			$si=$r['vest'];
			$main_news=$kon->query('SELECT * from vest WHERE status=1 AND sifra='.$si.'');
			$main_news=$main_news->fetch_assoc();
		}else{
			$main_news=$kon->query('SELECT * from vest WHERE status=1 ORDER BY vreme_objave DESC LIMIT 1');
			$main_news=$main_news->fetch_assoc();//ovaj deo je za glavnu vest,trazi id i pravi dalje instancu
		}
}




//ako nema izdvajamo



//sada selektuje najcitanije za deo sa strane
$sa_strane=$kon->query('SELECT vest.sifra,vest.naslov,vest.tekst,vest.vreme,vest.slika from vest INNER JOIN izdvajamo ON vest.sifra=izdvajamo.vest WHERE vest.status=1 ORDER BY vest.sifra DESC LIMIT 3');

$clanak=$kon->query('SELECT * FROM vest WHERE (kategorija=4 OR kategorija=5 OR kategorija=6 OR kategorija=7) AND status=1 ORDER BY vreme_objave DESC LIMIT 4');
$intervju=$kon->query('SELECT * FROM vest WHERE kategorija=3 AND status=1 ORDER BY vreme DESC LIMIT 3');


$izvestaji=$kon->query('SELECT * FROM vest WHERE kategorija=2 AND status=1 ORDER BY vreme DESC LIMIT 3');
$koncerti=$kon->query('SELECT * FROM vest WHERE kategorija=8 AND status=1 ORDER BY vreme DESC LIMIT 3');



















?>