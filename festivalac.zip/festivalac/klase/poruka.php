<?php
if(isset($_POST['por'])){
	$ime=trim(htmlspecialchars($_POST['ime']));
	$email=trim(htmlspecialchars($_POST['email']));
	$poruka=trim(htmlspecialchars($_POST['poruka']));


	if(mail("info@festivalac.com",$email,$poruka,'null','-fmail.festivalac.com'))
	    header('Location:../categories/contact.php?message=true');
	else header('Location:../categories/contact.php?message=false');

}else header('Location:../index.php');





?>