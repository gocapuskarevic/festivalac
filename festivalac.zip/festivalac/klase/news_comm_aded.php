<?php
require_once('PDO.php');
$svi_komentari=$kon->query("SELECT * FROM komentari WHERE vest=".$_GET['number']." AND odobri=1");
//var_dump($res->fetch_assoc());















?>