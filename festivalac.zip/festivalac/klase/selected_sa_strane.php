<?php
require('PDO.php');
$po_cemu=$_GET['number'];
$krit=$kon->query("SELECT kategorija From vest WHERE sifra=$po_cemu");
$krit=$krit->fetch_assoc();
$prom=$krit['kategorija'];
$ostalo=$kon->query("SELECT vest.sifra,vest.naslov,vest.slika FROM vest WHERE kategorija=$prom AND status=1 ORDER BY vest.klik DESC LIMIT 6");





?>