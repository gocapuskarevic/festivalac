<?php
require_once('PDO.php');
$spremne=$kon->query("SELECT sifra,vreme_objave FROM vest WHERE status=4");



//print_r($tr);


if($spremne->num_rows>0){
	while($dali=$spremne->fetch_assoc()){
		$date=new DateTime($dali['vreme_objave'],new DateTimeZone('Europe/Belgrade'));
		if($date->getTimestamp()<=time()){

			$sifra=$dali['sifra'];
			$kon->query("UPDATE vest SET status=1 WHERE sifra=$sifra");
		}
	}
}

?>