<?php
require_once('../klase/PDO.php');
require('../klase/grant_news.php');
$res=$kon->query('SELECT vest.sifra,vest.naslov,vest.tekst,vest.slika,vest.vreme,novinar.ime FROM vest INNER JOIN novinar ON novinar.sifra=vest.autor WHERE vest.status=0');
	
?>