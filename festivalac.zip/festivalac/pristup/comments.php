<?php
include_once('../PDO.php');
if(isset($_POST['grant'])){
	if($_POST['grant']=='Odobri'){
		$grant=$kon->prepare("UPDATE komentari SET odobri=? WHERE sifra=?");
		$odobrenje=true;
		$sifra=$_POST['hdn'];
		$grant->bind_param('si',$odobrenje,$sifra);
		if($grant->execute()){
			header('Location:../novinar/manage.php?odobrenje=true');
		}else header('Location:../novinar/manage.php?odobrenje=false');
	}

}else header('Location:../index.php');






?>