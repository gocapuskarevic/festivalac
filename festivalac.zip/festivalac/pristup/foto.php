<?php

	if($_FILES['foto']['size']>0){
		$slika=$_FILES['foto']['name'];
		if(move_uploaded_file($_FILES['foto']['tmp_name'],"../foto_report/".$_FILES['foto']['name'])){
			if($_GET['jezik']==0)
				echo '&ltimg src="../foto_report/'.$slika.'"&gt;';
			else echo '&ltimg src="../../foto_report/'.$slika.'"&gt;';
		}else header('Location:../novinar/administration/index_a.php?ann=image');
	}else header('Location:../novinar/administration/index_a.php?ann=imge');



?>