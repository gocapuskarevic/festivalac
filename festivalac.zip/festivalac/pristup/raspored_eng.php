<?php
require('../klase/PDO.php');
if(!empty($_POST)){
	$sifra=$_POST['sifra'];
	$vreme=$_POST['novo_vreme'];
	if(isset($_POST['draft'])){
		if($kon->query("UPDATE vest_eng SET status=2,vreme='$vreme',vreme_objave='$vreme' WHERE sifra=$sifra"))
			header('Location:../novinar/administration/pregled_mod_news.php?see='.$sifra.'&ann=draft');
		else echo $kon->error;
	}else if(isset($_POST['rasporedi'])){
		if(!empty(($_POST['time']))){
			$objava_kada=$_POST['time'];
			
			if($kon->query("UPDATE vest_eng SET status=4,vreme_objave='$objava_kada',vreme='$vreme' WHERE sifra=$sifra"))
				header('Location:../novinar/administration/pregled_mod_news.php?see='.$sifra.'&ann=raspored');
			else echo $kon->error;
		}else header('Location:../novinar/administration/pregled_mod_news.php?see='.$sifra.'&ann=vreme');
	}else if(isset($_POST['objavi'])){
		if($kon->query("UPDATE vest_eng SET status=1,vreme='$vreme',vreme_objave='$vreme' WHERE sifra=$sifra"))
			header('Location:../novinar/administration/pregled_mod_news.php?see='.$sifra.'&ann=objavljeno');
			else echo $kon->error;

	}else if($_POST['obrisi']){
		if($kon->query("UPDATE vest_eng SET status=3 WHERE sifra=$sifra"))
			header('Location:../novinar/administration/pregled_mod_news.php?see='.$sifra.'&ann=obrisano');
			else echo $kon->error;
	}else header('Location:../novinar/administration/pregled_mod_news.php?see='.$sifra.'&ann=no');

}else header('Location:../index.php');


?>