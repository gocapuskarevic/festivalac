<?php
session_start();
require_once('../klase/PDO.php');
$provera=$kon->query("SELECT mail FROM novinar");
$niz=array();
while($red=$provera->fetch_array())
	array_push($niz, $red['mail']);
if(in_array($_SESSION['sign'], $niz)){
	$autor=$kon->query("SELECT sifra FROM novinar WHERE mail='".$_SESSION['sign']."'");
	$au=$autor->fetch_assoc()['sifra'];
	$au=(int)$au;//ovde sad imamo autora
	if($_POST['language']=="on")
		$lang=1;
	else $lang=0;

	if($lang)
		$insert="INSERT INTO vest_eng(naslov,tekst,kategorija,autor,status,vreme,klik,slika,vreme_objave) VALUES(?,?,?,?,?,?,?,?,?)";//
	else $insert="INSERT INTO vest(naslov,tekst,kategorija,autor,status,vreme,klik,slika,vreme_objave) VALUES(?,?,?,?,?,?,?,?,?)";//nova vest se ubacuje
	
	if(isset($_POST['submit'])){
		if(!empty($_POST['title'])&&!empty($_POST['content'])){
			$title=trim($_POST['title']);
			$content=trim($_POST['content']);
			$cat=$_POST['category'];
			if($_FILES['image']['size']>0){
				$slika=$_FILES['image']['name'];
				if(move_uploaded_file($_FILES['image']['tmp_name'],"../images/".$_FILES['image']['name']))
							$klik=0;
							$status=0;
							$vreme = new DateTime("now", new DateTimeZone('Europe/Belgrade') );
							$vreme=$vreme->format('Y-m-d H:i:s');
							$vreme=str_replace(' ', 'T', $vreme);
							
				$result=$kon->prepare($insert);
				if($result->bind_param('ssiiisiss',$title,$content,$cat,$au,$status,$vreme,$klik,$slika,$vreme)){
					if($result->execute()){
						$vest=$kon->insert_id;
						
						//ovde se dodaju tagovi u bazu
						$tagovi=$_POST['tagovi'];
						if($tagovi){
							$tag = explode(",", $tagovi);
							for($i=0;$i<count($tag);$i++){
								if(preg_match('~[0-9]+~', $tag[$i])&&$tag[$i]!=''){
									if($lang)
										$dodati=$kon->query("INSERT INTO tag_vest_eng(vest,tag) VALUES($vest,$tag[$i])");
									else $dodati=$kon->query("INSERT INTO tag_vest(vest,tag) VALUES($vest,$tag[$i])");
									if(!$dodati)
										echo $kon->error;//header('Location:../novinar/administration/index_a.php?ann=nijeprosaoinsertvest_tag');
									//sad ispod ako nije numeric stavljamo prvo novi pa u zajednicku
								}else if(!preg_match('~[0-9]+~', $tag[$i])&&$tag[$i]!=''){
									$ubacujemo_novi=$kon->query("INSERT INTO tagovi(imetaga) VALUES('$tag[$i]')");
									if(!$ubacujemo_novi) echo $kon->error;
									else{
										$sifra_tag=$kon->insert_id;
										if($lang)
											$dodajemo_opet=$kon->query("INSERT INTO tag_vest_eng(vest_eng,tag) VALUES($vest,$sifra_tag)");
										else $dodajemo_opet=$kon->query("INSERT INTO tag_vest(vest,tag) VALUES($vest,$sifra_tag)");
										if(!$dodajemo_opet)
											echo $kon->error;
										}
									}
								}
							}//zavrsava se for petlja ovde i deo sa tagovima
							if($_POST['izdvajamo']=='on'){//da li je kliknuto izdvajamo
								if($lang){
									if(!$kon->query("INSERT INTO izdvajamo_eng(vest) VALUES($vest)"))
									echo $kon->error;
								}else{
									if(!$kon->query("INSERT INTO izdvajamo(vest) VALUES($vest)"))
									echo $kon->error;
								}
							}

							if($_POST['naslovna']=='on'){//da li je kliknuto izdvajamo
								$dan=$_POST['naslovna_datum'];
								if($lang){
									if(!$kon->query("INSERT INTO glavna_eng(vest,datum) VALUES($vest,'$dan')"));
									echo $kon->error;
								}else{
									if(!$kon->query("INSERT INTO glavna(vest,datum) VALUES($vest,'$dan')"));
									echo $kon->error;
								}
								
							}
							header('Location:../novinar/administration/index_a.php?ann=true');

					}else echo $kon->error;//header('Location:../novinar/administration/index_a.php?ann=nijeprosaoexecute');

			}else header('Location:../novinar/administration/index_a.php?ann=nijeprosaobind');
		}else header('Location:../novinar/administration/index_a.php?ann=nijeizabranaslika');//ako nije sacuvana slika vraca na index inace idemo dalje
			//sad pravimo ostale promenljive za sve
		


		}else header('Location:../novinar/administration/index_a.php?ann=empty');

	}else header('Location:../index.php');
	




}else header('Location:../index.php');

?>